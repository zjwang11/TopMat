#!/bin/bash

ifort Symmat.f90 -o symmat # -g -traceback -check all

