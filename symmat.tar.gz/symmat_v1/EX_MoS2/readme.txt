#shell commande
    ### run vasp scf ###
$ vim INCAR  (set “ISYM = 2; LWAVE = .T. ”)
$ mpirun -np $ncpu $vasp_ncl  > out 2> err
$ cp OUTCAR OUTCAR.scf                        
$ cp EIGENVAL EIGENVAL.scf
    ### run vasp2mat < INCAR.mat > fort.1315-17 ###
$ vim INCAR  (set “ISTART = 1; ICHARG =  11;  LWAVE = .F.  ”)
$ vasp2mat > mat.out
    ### run symmat   ###
$ symmat -noe 26 			    	# berry_0.dat is berry curvature
$ cp berry_0.dat berry.dat; gnuplot plot_berry.gnu # plot berry curvature

