#shell commande
$ vim INCAR  (set “ISYM = 2; LWAVE = .T. ”)
$ mpirun -np $ncpu vasp_ncl  > out 2> err
$ cp OUTCAR OUTCAR.scf                        
$ cp EIGENVAL EIGENVAL.scf
    ### run vasp2mat < INCAR.mat > fort.1315-17 ###
$ vim INCAR  (set “ISTART = 1; ICHARG =  11;  LWAVE = .F.  ”)
$ vasp2mat > mat.out
    ### run symmat   ###
$ symmat -noe 4     # dielectric_constants.dat       
$ gnuplot plot_diel.gnu



