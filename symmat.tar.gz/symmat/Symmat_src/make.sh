#!/bin/bash


ifort symmat.f90 -o Symmat #-g -traceback -check all

