#配置环境
cd ~/data
cp -r /tmp/vasp2kp .
cd vasp2kp
source env.sh

###example1: Bi2Se3
#scf
cd ~/data/vasp2kp/example/Bi2Se3/scf
sbatch sub-vasp.slurm

#get WAVECAR
cd ~/data/vasp2kp/example/Bi2Se3/Gamma-wavecar
ln -sf ../scf/CHGCAR .
sbatch sub-vasp.slurm

#irvsp
cd ~/data/vasp2kp/example/Bi2Se3/Gamma-wavecar
sbatch sub-irvsp.slurm

#vasp2mat
cd ~/data/vasp2kp/example/Bi2Se3/vasp2mat
cp ../Gamma-wavecar/POSCAR .
cp ../Gamma-wavecar/POTCAR .
cp ../Gamma-wavecar/KPOINTS .
cp ../Gamma-wavecar/WAVECAR .
sbatch sub-vasp2mat.slurm

#mat2kp
cd ~/data/vasp2kp/example/Bi2Se3/mat2kp
mkdir Bi2Se3-mat
cp ~/data/vasp2kp/example/Bi2Se3/Gamma-wavecar/EIGENVAL Bi2Se3-mat/.
cp ~/data/vasp2kp/example/Bi2Se3/vasp2mat/MAT_* Bi2Se3-mat/.
sbatch sub-mat2kp.slurm



###example2: MoTe2
#scf
cd ~/data/vasp2kp/example/MoTe2/scf
sbatch sub-vasp.slurm

#get WAVECAR
cd ~/data/vasp2kp/example/MoTe2/K-wavecar
ln -sf ../scf/CHGCAR .
sbatch sub-vasp.slurm

#irvsp
cd ~/data/vasp2kp/example/MoTe2/K-wavecar
sbatch sub-irvsp.slurm

#vasp2mat
cd ~/data/vasp2kp/example/MoTe2/vasp2mat
cp ../K-wavecar/POSCAR .
cp ../K-wavecar/POTCAR .
cp ../K-wavecar/KPOINTS .
cp ../K-wavecar/WAVECAR .
sbatch sub-vasp2mat.slurm

#mat2kp
cd ~/data/vasp2kp/example/MoTe2/mat2kp
mkdir MoTe2-mat
cp ../K-wavecar/EIGENVAL MoTe2-mat/.
cp ../vasp2mat/MAT_* MoTe2-mat/.
sbatch sub-mat2kp.slurm



###example3: Na3Bi
#scf
cd ~/data/vasp2kp/example/Na3Bi/scf
sbatch sub-vasp.slurm

#get WAVECAR
cd ~/data/vasp2kp/example/Na3Bi/DT-wavecar
ln -sf ../scf/CHGCAR .
sbatch sub-vasp.slurm

#irvsp
cd ~/data/vasp2kp/example/Na3Bi/DT-wavecar
sub-irvsp.slurm

#vasp2mat
cd ~/data/vasp2kp/example/Na3Bi/vasp2mat
cp ../DT-wavecar/POSCAR .
cp ../DT-wavecar/POTCAR .
cp ../DT-wavecar/KPOINTS .
cp ../DT-wavecar/WAVECAR .
sbatch sub-vasp2mat.slurm

#mat2kp
cd ~/data/vasp2kp/example/Na3Bi/mat2kp
mkdir Na3Bi-mat
cp ../DT-wavecar/EIGENVAL Na3Bi-mat/.
cp ../vasp2mat/MAT_* Na3Bi-mat/.
sbatch sub-mat2kp.slurm