      PROGRAM MOM2MSG
      use parlib
      use mathlib
      use context
      use find_msg
!      use find_ssg
      implicit none

      integer :: num_sym
      integer :: num_atom, num_atomtypes
      integer :: num_atoms_pertype(111)
      !real(dp) :: mag_cart(3,999)
      integer :: space_group
      integer :: pri_sym
      integer ::  topa(1920), gopa(1920), tgopa(1920)
      character(80):: mtype
      character(20):: mresult
      integer :: mtag
      integer :: countsub
      integer ::  SG_A, SG_B
      integer :: M_SG(3)
      character(60) :: header60
      character(61) :: header61
      integer ::  head_cor


      !> international notion of space group
      character(len=11) :: international

      !> Schoenflies notion of space group
      character(len=7) :: schoenflies
      
      integer :: i, j, ii

      integer , allocatable :: posi2type(:)
      integer , allocatable :: atom_types(:)
      integer , allocatable :: eqv_map(:,:)
      integer , allocatable :: meqv_map(:,:)
      integer , allocatable :: rotations(:, :, :)
      integer , allocatable :: hel2type(:)
      integer , allocatable :: tag(:)
      integer, allocatable :: rotations_wyckoff(:, :, :, :)
      integer, allocatable :: magrotations_wyckoff(:, :, :, :)
      real(dp), allocatable :: positions(:, :)
      real(dp), allocatable :: mpositions(:, :)
      real(dp), allocatable :: eqv_pos(:,:)
      real(dp), allocatable :: translations(:, :)
      real(dp), allocatable :: helium(:,:), heliump(:,:)
      real(dp), allocatable :: translations_wyckoff(:, :, :)

      allocate(posi2type   (max_num_atom))
      allocate(atom_types  (max_num_atom))
      allocate(eqv_map     (2,max_num_atom))
      allocate(meqv_map    (2,max_num_atom))
      allocate(eqv_pos     (6,max_num_atom))
      allocate(rotations   (3, 3, max_num_sym))
      allocate(hel2type    (max_num_atom))
      allocate(tag         (2 * max_num_sym))
      allocate(positions   (3, max_num_atom))
      allocate(mpositions  (3, max_num_atom))
      allocate(translations(3, max_num_sym))
      allocate(helium      (3, max_num_sym))
      allocate(heliump     (3, max_num_sym))
      
      hel2type = 0
      helium = 0._dp
      heliump = 0._dp
      num_atom = 0
      num_atomtypes = 0
      mtype = ''

      !<1> read poscar
      call read_poscar(num_atom, num_atomtypes, num_atoms_pertype,  positions, mpositions, atom_types)
      !mag_cart=0._dp;mag_cart(:,1:num_atom)=mpositions(:,1:num_atom)
      do i=1, num_atom 
            call cartesian_to_direct(mpositions(:, i), lattice)
      enddo

      ii=1;j=0
      posi2type= 0
      do i=1,num_atom
      posi2type(i)=atom_types(ii)
      j=j+1
      if(j==num_atoms_pertype(ii)) then
            j=0;ii=ii+1
      endif
      enddo

      !<2> find space group symmetry
      call get_spg_information(num_atom,positions,posi2type,num_sym,space_group,rotations,translations,international,schoenflies)
      write(*, '( 27X,"Int.      Sch.    #SG   #symm ")')
      write(*, '( "Crystalline SG(org.):",A10,A10,2I7)')  trim(international), trim(schoenflies), space_group, num_sym

!!!zrh
      call find_eqatoms(num_atom,posi2type,num_sym,positions,mpositions,rotations,translations,symprec,eqv_map,eqv_pos)

     !allocate(rotations_wyckoff(3, 3, max_num_sym, maxval(eqv_map(2,:))))
     !allocate(magrotations_wyckoff(3, 3, max_num_sym, maxval(eqv_map(2,:))))
     !allocate(translations_wyckoff(3, max_num_sym, maxval(eqv_map(2,:))))

     !call get_pg_wyckoff(num_atom,eqv_map,eqv_pos,maxval(eqv_map(2,:)),rotations_wyckoff,translations_wyckoff,magrotations_wyckoff)

     !deallocate(rotations_wyckoff,magrotations_wyckoff)
     !deallocate(translations_wyckoff)
      
      call write_wp('WPOS.dat',num_atom,posi2type,eqv_map,eqv_pos)
      call write_mom(num_atom,eqv_map,eqv_pos)
      
 !! zrh                
      !!!!find symm of ,1:8{E|t}
      pri_sym= 0
      do i=2,num_sym
            if( sum(abs(rotations(:,:,i)- rotations(:,:,1)))<0.01) then
                  pri_sym=i-1
                  exit
            endif
      enddo
      
      !<3> find magnetic symmetry
      call find_symm(rotations,translations,positions,mpositions,posi2type,num_sym,num_atom,topa,gopa,tgopa)
      
      call classify_magnetism(eqv_pos(4:6,:), num_atom, tolerance1, mresult)

      !!! output magnetic symmetry information to msgout.txt
      call write_msgout(num_sym, rotations, translations, gopa, tgopa, mtype, mtag, mresult)
  
      call find_eqmom(num_atom,num_sym,rotations,translations,gopa,tgopa,tolerance2,eqv_map,eqv_pos,meqv_map)
      call write_wp('MWPOS.dat',num_atom,posi2type,meqv_map,eqv_pos)

      !<4> add helium atoms to the effctive mwyckoff positions
      call addHe(num_sym,num_atom,topa,gopa,positions,rotations,translations,heliump,helium,hel2type,countsub,tag)

      !<5> find magnetic space group SG_A and SG_B
      call get_spg_information(countsub+num_atom,heliump,hel2type,num_sym,SG_B,rotations,translations,international,schoenflies)

      if (SG_B /= 0) then
      write(*, '( "unitary  part (only):",A10,A10,2I7)')  trim(international), trim(schoenflies), SG_B, num_sym
      else
      print '("Space group could not be found,")'
      end if

      hel2type(:)=100
      
      call get_spg_information(countsub+num_atom,heliump,hel2type,num_sym,SG_A,rotations,translations,international,schoenflies)

      if (mtag == 2) num_sym = num_sym*2

      if (SG_A /= 0) then
      write(*, '( "unitary +antiunitary:",A10,A10,2I7)')  trim(international), trim(schoenflies), SG_A, num_sym
      else
      print '("Space group could not be found,")'
      end if
      write(*,*)
      write(*, '( "Moment classification:  ",A20)') mresult

      !<6> find magnetic space group number through SG_A and SG_B
      M_SG = 0
      call SGAB2msgOG(SG_A,SG_B,mtag,M_SG,header60)
      !!! output
      write(*,*) 
      write(*, '( "Magnetic SG type : ",a)') trim(adjustl(mtype))
      if (M_SG(2)/=0 .and. mtag/=3) then
      write(*, '( "Magnetic SG number (OG) : ",I5,",",I5"   (Warning)" )')M_SG(1),M_SG(2)
      write(header61,"(A60)") header60(:)
      write(*,*) header61
      elseif (M_SG(2)==0) then
      write(*, '( "Magnetic SG number (OG) : ",I5 )') M_SG(1)
      write(header61,"(A60)") header60(:)
      write(*,*) header61
      else
      
      call correct_OG(num_sym,pri_sym,M_SG,rotations,translations,tgopa,M_SG(3),head_cor)
      write(header61,"(A17,I2,'.',I4,A34)") header60(:17),head_cor,M_SG(3),header60(25:)
      write(*, '( "Magnetic SG number (OG) : ",I5 )') M_SG(3)
      write(*,*) header61
      endif

      if (mtag/=2) then
         if (mtag==1  .and. space_group==SG_B) then 
            continue
         else
            write(*,'("He:")')
            do j= 1,countsub  
               write(*, "(3f12.8)") helium(:,j)
            enddo
         endif
      endif

      !<7> generate effctive POSCAR
      call write_poscar_msg(header61, mtag, num_atom, num_atomtypes, num_atoms_pertype, atom_types, eqv_pos, helium, tag, countsub)

      
      deallocate(positions,mpositions,atom_types,rotations,translations)
      deallocate(posi2type)
      deallocate( helium, heliump)
      deallocate(hel2type)
      deallocate(tag)
      deallocate(eqv_map)
      deallocate(meqv_map)
      deallocate(eqv_pos)

      END PROGRAM
