module find_msg
use parlib, only: dp, max_num_sym,symprec,max_num_atom
use context, only: lattice
implicit none
public :: SGAB2msgOG
public :: correct_OG
public :: get_spg_information
contains

subroutine get_spg_information(num_atom,positions,posi2type,num_sym,space_group,rotations,translations,international,schoenflies)
   integer, intent(in) :: num_atom
   integer, intent(out) :: num_sym
   integer, intent(out) :: space_group
   real(dp) :: lattice_t(3,3)
   real(dp), intent(out) :: translations(3, max_num_sym)
   real(dp), intent(in) :: positions(3, max_num_atom)
   integer, intent(in) :: posi2type(max_num_atom)
   integer, intent(out) :: rotations(3, 3, max_num_sym)
   character(len=11), intent(out) :: international
   character(len=7), intent(out), optional :: schoenflies

   integer :: i

   translations=0._dp
   rotations=0

  lattice_t = transpose( lattice )
  num_sym= max_num_sym
  call spg_get_symmetry( num_sym, rotations, translations, max_num_sym, &
         lattice_t, positions, posi2type, num_atom, symprec)

  call spg_get_international( space_group, international, & 
         lattice_t, positions, posi2type, num_atom, symprec)

   if (present(schoenflies)) then
      if (space_group /= 0) call spg_get_schoenflies( space_group, schoenflies, & 
               lattice_t, positions, posi2type, num_atom, symprec)
   endif

   do i = 1, num_sym
     rotations(:,:,i) = transpose(rotations(:,:,i))
  end do
endsubroutine

subroutine SGAB2msgOG(SGA,SGB,MTYPE,MSG,lan)
use parlib, only: OG_zrh
integer, intent(in)  :: SGA, SGB, MTYPE
integer, intent(out) :: MSG(2)
character(60),intent(out) :: lan
integer :: tmp11(4,230), tmp22(3,230), og_middle, og_middle2
integer :: i, j, k, ii
MSG=0
       tmp11=0
       tmp22=0
       j=1
       do i = 1,1651
          if (OG_zrh(3,i)==SGA) then
              tmp11(1,j)=OG_zrh(1,i)
              tmp11(2,j)=OG_zrh(2,i)
              tmp11(3,j)=OG_zrh(4,i)
              tmp11(4,j)=OG_zrh(5,i)
              j=j+1          
          endif
       enddo
       k=1
       do i = 1,j-1
          if (tmp11(3,i)==SGB) then
              tmp22(1,k)=tmp11(1,i)
              tmp22(2,k)=tmp11(2,i)
              tmp22(3,k)=tmp11(4,i)
              k=k+1
          endif
       enddo
       ii = 1
       do i = 1,k-1
          if (tmp22(2,i)==MTYPE) then
              MSG(ii)=tmp22(1,i)
              ii=ii+1
          endif
       enddo
       og_middle=0
       og_middle2=0
       do i = 1,j-1
          if (tmp11(1,i)==MSG(1)) then
             og_middle=tmp11(4,i)
             if (MSG(2)/=0 .and. MTYPE/=3) then
                og_middle2 = MSG(2)-MSG(1)+og_middle
                write(lan,"('SG#B',I3,'   OG(',I3,'.',I2,'.',I4,' / ',I3,'.',I2,'.',I4,' )')") SGB,SGA,og_middle,MSG(1),SGA,og_middle2,MSG(2)
             else
                write(lan,"('SG#B',I3,'   OG(',I3,'.',I2,'.',I4,' )')") SGB,SGA,og_middle,MSG(1)
             endif
          endif 
       enddo

end subroutine SGAB2msgOG

 subroutine correct_OG(num_sym,pp_sym,MSG,rotations,translations,tgopa,MSG_correct,head_correct)
 use parlib, only: dp
 use mathlib, only: Matrix_Det
 integer, intent(in)  :: MSG(3), tgopa(max_num_sym), rotations(3,3,max_num_sym), num_sym, pp_sym
 real(dp), intent(in)  :: translations(3,max_num_sym)
 integer, intent(out) :: MSG_correct, head_correct
 integer ::  tmp33(3,3), tmp332(3,3), s_index, k
 real(dp) :: transdiff(3,max_num_sym), det, tmp3(3), rtmp
   integer :: i, j
     MSG_correct = 0
     det = 0.0
     tmp33=0
     tmp332=0
     tmp3=0
     s_index=1
     if (pp_sym/=0) then
        s_index = num_sym/pp_sym
     endif

     if (MSG(1) == 200) then
        MSG_correct = MSG(2)
        head_correct = 4
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33(:,:)= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (3+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif

     if (MSG(1) == 207) then
        MSG_correct = MSG(2)
        head_correct = 4
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (3+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif

     if (MSG(1) == 228) then
        MSG_correct = MSG(2)
        head_correct = 4
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (3+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif
     
     if (MSG(1) == 381) then
        MSG_correct = MSG(2)
        head_correct = 6
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (8+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif

     
     if (MSG(1) == 411) then
        MSG_correct = MSG(2)
        head_correct = 7
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (6+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif


     if (MSG(1) == 433) then
        MSG_correct = MSG(2)
        head_correct = 7
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (8+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif
 


     if (MSG(1) == 493) then
        MSG_correct = MSG(2)
        head_correct = 7
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (6+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif


     if (MSG(1) == 507) then
        MSG_correct = MSG(2)
        head_correct = 7
        do i= 1,num_sym
        if (tgopa(i)/=0) then
              tmp33= rotations(:,:,i)
              call Matrix_Det(tmp33(:,:),3,det)
              if (det<0) then
                 do j= 1,s_index
                    k=pp_sym*(j-1)
                    if (6+k==i) then
                       MSG_correct = MSG(1)
                       head_correct = head_correct-1
                    endif
                 enddo
              endif
        endif
        enddo
     endif



 
 end subroutine correct_OG


 subroutine addHe(num_sym,num_atom,topa,gopa,positions,rotations,translations,heliump,helium,hel2type,countsub,tag)
use parlib, only: dp
implicit none
integer, intent(in) :: num_sym
integer, intent(in) :: num_atom
real(dp), intent(in) :: positions(3,max_num_atom)
integer, intent(in) :: topa(max_num_sym), gopa(max_num_sym)
integer, intent(in) :: rotations(3,3,max_num_sym)
real(dp), intent(in) :: translations(3,max_num_sym)
real(dp) :: helium1(3)
real(dp), intent(out) :: heliump( 3,max_num_sym)
real(dp) :: helium22(3,1920)
real(dp) :: helium2( 3,max_num_sym)
real(dp), intent(out) :: helium(3, max_num_sym) 
integer, intent(out) :: hel2type(max_num_atom)
integer :: i, j, k
integer, intent(out) :: countsub
integer,intent(out) :: tag(max_num_sym*2)

   helium1(:)=([0.11,0.12,0.31])
    countsub= 0
    tag=0
    do j= 1,num_sym
    if (topa(j) /= 0) then
       helium2(:,j) =matmul(rotations(:,:,j),helium1)          
       countsub = countsub + 1
       if (gopa(j) /=0) tag(countsub)=1
    do k=1,3
    helium(k,countsub)= helium2(k,j)+translations(k,j)
    enddo
    endif 
    enddo

    helium22= 0._dp
    helium22=helium
    helium=0
    j=0
    do i=1,countsub
       if (tag(i) ==1) then
          j=j+1
          tag(j+countsub) = 1
          helium(:,j) = helium22(:,i)
       endif
    enddo
    do i=1,countsub
       if (tag(i) ==0) then
          j=j+1
          helium(:,j) = helium22(:,i)
       endif
    enddo
        
      heliump(:,1:num_atom)=positions(:,1:num_atom)
      
      heliump(:,1+num_atom:countsub+num_atom)=helium(:,1:countsub)

  hel2type(:)=100;hel2type(num_atom+1:num_atom+countsub)=tag(countsub+1:2*countsub)
 endsubroutine

 subroutine find_symm(rotations,translations,positions,mpositions,posi2type,num_sym,num_atom,topa,gopa,tgopa)
use mathlib, only: Matrix_Det
use parlib, only: tolerance2
implicit none
 !!!! find unit & anti-unit symm
   integer, intent(in) :: num_atom
   integer, intent(in) :: num_sym
   real(dp), intent(in) :: positions(3,max_num_atom), mpositions(3,max_num_atom)
   integer, intent(in) :: rotations(3, 3, max_num_sym)
   real(dp), intent(in) :: translations(3, max_num_sym)
   integer, intent(out):: topa(max_num_sym), gopa(max_num_sym), tgopa(max_num_sym)
   integer :: tg(max_num_sym,max_num_atom),g(max_num_sym,max_num_atom) 
   integer :: i, j, k
   real(dp) :: det
   real(dp), allocatable :: res_o(:,:,:), mres_o(:,:,:), tmres_o(:,:,:)
   integer :: tmp33(3,3)
   integer :: posi2type(num_atom)
   real(dp) :: difftmp
   allocate(res_o  (3,max_num_sym,max_num_atom))
   allocate(mres_o (3,max_num_sym,max_num_atom))
   allocate(tmres_o(3,max_num_sym,max_num_atom))

  topa=0;gopa=0;tgopa=0
  tg=0;g=0

  do i= 1,Num_atom
      do j= 1,num_sym
         res_o(:,j,i) =matmul(rotations(:,:,j),positions(:,i))+translations(:,j)  
          mres_o(:,j,i) =matmul(rotations(:,:,j),mpositions(:,i))          
          tmp33= rotations(:,:,j)
          call Matrix_Det(tmp33(:,:),3,det)
          mres_o(:,j,i)= det*mres_o(:,j,i)
          tmres_o(:,j,i)= -1*mres_o(:,j,i)
      enddo 
  enddo    

 !##################### tgotpot
 do j= 1,num_sym
 do i= 1,num_atom
 do k= 1,num_atom
 if (posi2type(i)==posi2type(k)) then
     difftmp = res_o(1,j,i)-positions(1,k)
     if(abs(difftmp - real(nint(difftmp),dp))< tolerance2 ) then 
     difftmp = res_o(2,j,i)-positions(2,k)
     if(abs(difftmp - real(nint(difftmp),dp))< tolerance2 ) then 
     difftmp = res_o(3,j,i)-positions(3,k)
     if(abs(difftmp - real(nint(difftmp),dp))< tolerance2 ) then 

      if (all(abs(mres_o(:,j,i)-mpositions(:,k)) < tolerance2)) then
            g(j,i)=j
      endif

      if (all(abs(tmres_o(:,j,i)-mpositions(:,k)) < tolerance2)) then
            tg(j,i)=j
      endif

     endif
     endif
     endif
 endif
 enddo
 enddo
 enddo

!!!!!!topa: total operator
!!!!!!gopa: spg operator
!!!!!!tgopa: time reversal * spg operator

    do j= 1,num_sym
     difftmp=1
     do i= 1,num_atom
      difftmp=difftmp*g(j,i)
     enddo
     if (difftmp/=0)then
      topa(j)=j
      gopa(j)=j
     endif
   
     difftmp=1
     do i= 1,num_atom
      difftmp=difftmp*tg(j,i)
     enddo
     if (difftmp/=0)then
      topa(j)=j
      tgopa(j)=j
     endif
    enddo
    deallocate(res_o, mres_o , tmres_o)
 !##################### tgotpot
 endsubroutine

end module
