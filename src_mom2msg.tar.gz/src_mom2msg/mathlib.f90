module mathlib
use parlib,only:dp

private

public :: cartesian_to_direct
public :: direct_to_cartesian
public :: Matrix_Det
public :: classify_vectors_sub
public :: check_zero_vectors

contains
subroutine inv3(mat)
   
   implicit none

   real(dp), intent(inout)  :: mat (3, 3)
   real(dp) :: mat_in(3, 3)
   real(dp) :: mat_out(3, 3)
   real(dp) :: a11, a12, a13, a21, a22, a23, a31, a32, a33, denominator
   mat_in= mat

   a11= mat_in(1, 1); a12= mat_in(1, 2); a13= mat_in(1, 3)
   a21= mat_in(2, 1); a22= mat_in(2, 2); a23= mat_in(2, 3)
   a31= mat_in(3, 1); a32= mat_in(3, 2); a33= mat_in(3, 3)

   denominator= -a13*a22*a31+ a12*a23*a31+ a13*a21*a32- a11*a23*a32- a12*a21*a33+ a11*a22*a33

   mat_out(1, 1)= -a23*a32+ a22*a33; mat_out(1, 2)= a13*a32- a12*a33; mat_out(1, 3)= -a13*a22+ a12*a23
   mat_out(2, 1)=  a23*a31- a21*a33; mat_out(2, 2)=-a13*a31+ a11*a33; mat_out(2, 3)=  a13*a21- a11*a23
   mat_out(3, 1)= -a22*a31+ a21*a32; mat_out(3, 2)= a12*a31- a11*a32; mat_out(3, 3)= -a12*a21+ a11*a22
   mat= mat_out/denominator

   return
end subroutine inv3

SUBROUTINE Matrix_Det(B,N,DET)
      DIMENSION A(N,N),B(N,N)
      DOUBLE PRECISION DET,F,D,Q
      integer  :: B 
      real(8)  :: A
      A=real(B,8)
      F=1.0_8
      DET=1.0_8
      DO 100 K=1,N-1
      Q=0.0
      DO 10 I=K,N
      DO 10 J=K,N
        IF (ABS(A(I,J)).GT.Q) THEN
          Q=ABS(A(I,J))
          IS=I
          JS=J
        END IF
10   CONTINUE
      IF (Q+1.0.EQ.1.0) THEN
        DET=0.0
        RETURN
      END IF
      IF (IS.NE.K) THEN
        F=-F
        DO 20 J=K,N
          D=A(K,J)
          A(K,J)=A(IS,J)
          A(IS,J)=D
20     CONTINUE
      END IF
      IF (JS.NE.K) THEN
        F=-F
        DO 30 I=K,N
          D=A(I,JS)
          A(I,JS)=A(I,K)
          A(I,K)=D
30     CONTINUE
      END IF
      DET=DET*A(K,K)
      DO 50 I=K+1,N
        D=A(I,K)/A(K,K)
        DO 40 J=K+1,N
40     A(I,J)=A(I,J)-D*A(K,J)
50   CONTINUE
100   CONTINUE
      DET=F*DET*A(N,N)
      RETURN
      END

subroutine cartesian_to_direct(pos, lattice)
   implicit none

   real(dp), intent(inout) :: pos(3)
   real(dp), intent(in) :: lattice(3, 3)
   real(dp) :: inv_lattice(3, 3), pos_temp(3)

   inv_lattice= transpose(lattice)
   call inv3(inv_lattice)
   pos_temp= pos(1)*inv_lattice(1, :)+ pos(2)*inv_lattice(2, :)+ pos(3)*inv_lattice(3, :)
   pos= pos_temp

   return
end subroutine cartesian_to_direct

subroutine direct_to_cartesian(pos, lattice)
  implicit none

  real(dp), intent(inout) :: pos(3)           
  real(dp), intent(in)    :: lattice(3, 3)    
  real(dp) :: pos_temp(3)

  pos_temp = pos(1)*lattice(:,1) + pos(2)*lattice(:,2) + pos(3)*lattice(:,3)
  pos = pos_temp

  return
end subroutine direct_to_cartesian

  subroutine cross_product(a, b, c)
    real(dp), intent(in)  :: a(3), b(3)
    real(dp), intent(out) :: c(3)
    c(1) = a(2)*b(3) - a(3)*b(2)
    c(2) = a(3)*b(1) - a(1)*b(3)
    c(3) = a(1)*b(2) - a(2)*b(1)
  end subroutine cross_product


  subroutine classify_vectors_sub(V, N, tol, class)
  ! classify_vectors_sub:
  ! 判断一组三维向量是否共线、共面或一般情况
  ! 输入:
  !   V(3,N)       - N 个三维矢量（列存储）
  !   N            - 矢量个数
  !   tol (可选)   - 匹配容差, 默认 1e-6
  ! 输出:
  !   class        - 1: 共线(collinear)
  !                  2: 共面(coplanar)
  !                  3: 非共面也非共线(general)
  ! 注意: V 中可能包含零向量
    integer,  intent(in)  :: N
    real(dp), intent(in)  :: V(3, N)
    real(dp), intent(in)  :: tol
    integer,  intent(out) :: class
    real(dp) :: epsilon
    real(dp) :: v1(3), v2(3), cp(3)
    real(dp) :: norm_v1, norm_cp
    integer :: i, idx2

    epsilon = tol

    ! 少于 2 个矢量，或所有矢量近似零，都视为共线
    if (N < 2) then
      class = 1
      return
    end if

    ! 找第一个非零向量 v1
    v1 = 0.0_dp
    do i = 1, N
      if (sqrt(sum(V(:,i)**2)) > epsilon) then
        v1 = V(:,i)
        exit
      end if
    end do
    norm_v1 = sqrt(sum(v1**2))
    if (norm_v1 < epsilon) then
      class = 1
      return
    end if

    ! 在剩余矢量中找与 v1 不共线的 v2
    idx2 = 0
    do i = 1, N
      call cross_product(v1, V(:,i), cp)
      norm_cp = sqrt(sum(cp**2))
      if (norm_cp > epsilon) then
        v2 = V(:,i)
        idx2 = i
        exit
      end if
    end do
    ! 如果没找到，则共线
    if (idx2 == 0) then
      class = 1
      return
    end if

    ! v1, v2 构成平面基，检查所有向量是否都在该平面内
    do i = 1, N
      call cross_product(v1, V(:,i), cp)
      ! 判断 cp 是否与 v2 共线，即 triple scalar = dot(cp, v2)
      if (abs(sum(cp * v2)) > epsilon * norm_v1 * sqrt(sum(v2**2))) then
        class = 3
        return
      end if
    end do

    ! 若未跳出，则所有向量共面
    class = 2
  end subroutine classify_vectors_sub


subroutine check_zero_vectors(A, has_zero_col, all_zero_cols, eps)
  implicit none
  real(kind=8), intent(in)            :: A(:,:)               ! 任意大小二维实数组
  logical,       intent(out)          :: has_zero_col         ! 是否存在零列
  logical,       intent(out)          :: all_zero_cols        ! 是否全部为零列
  real(kind=8),  intent(in), optional :: eps                  ! 数值容差（可选）

  real(kind=8) :: tol

  tol = merge(eps, 1.0d-12, present(eps))

  has_zero_col  = any( all(abs(A) <= tol, dim = 1) )
  all_zero_cols = all( all(abs(A) <= tol, dim = 1) )
end subroutine check_zero_vectors


endmodule
