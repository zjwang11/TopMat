module context
use parlib,only:dp,tolerance1,Atomic_names
implicit none

real(dp), public,save :: lattice(3, 3)

public :: read_poscar
public :: get_atomic_index
contains

subroutine read_poscar(Num_atoms, num_atomtypes, num_atoms_pertype, atom_positions, mag_positions, atom_types)
   use parlib, only:max_num_atom,max_num_sym
   !> This subroutine reads the POSCAR file and extracts the lattice parameters,
   !> atomic positions, and types of atoms.
   integer, intent(inout) :: Num_atoms 
   integer, intent(inout) :: num_atomtypes
   real(dp), intent(out) :: atom_positions(3, max_num_atom)
   real(dp), intent(out) :: mag_positions(3, max_num_atom)
   integer, intent(out) :: atom_types(max_num_atom)
   character(20):: filename
   integer, intent(out) :: num_atoms_pertype(111)
   !integer :: i

    num_atoms= 1
    num_atoms_pertype= 0


   filename = 'POSCAR'
   call read_poscar_(filename, Num_atoms, num_atomtypes, num_atoms_pertype, atom_positions, mag_positions, atom_types, .true.)
   call read_poscar_(filename, Num_atoms, num_atomtypes, num_atoms_pertype, atom_positions, mag_positions, atom_types, .false.)

end subroutine read_poscar

subroutine read_poscar_(filename, Num_atoms, num_atomtypes, num_atoms_pertype, atom_positions, mag_positions, atom_types, lcount)
   use parlib, only:max_num_atom,max_num_sym
   use mathlib, only: cartesian_to_direct
   implicit none

   integer, intent(inout) :: num_atoms 
   integer, intent(inout) :: num_atomtypes
   real(dp), intent(out) :: atom_positions(3, max_num_atom)
   real(dp), intent(out) :: mag_positions(3, max_num_atom)
   integer, intent(out) :: atom_types(max_num_atom)
   character(20), intent(in) :: filename
   integer, intent(out) :: num_atoms_pertype(111)
   !> lcount=.true. count howmany atoms only
   !> lcount=.false. write out lattice, atom_positions, atom_types
   logical, intent(in) :: lcount

   integer :: i,ierr
   logical :: existed, with_atom_name
   real(dp) :: rscale
   character(180):: chat180
   character(1) :: firstcharacter, directorcart
   character(3) :: atom_name(num_atomtypes)

   !> check if POSCAR is existed
   inquire(file=filename, exist=existed)
   if (.not. existed) stop ">>> ERROR: File POSCAR is not existed"
 
   open(unit=1010, file=filename)
   
   !> a comment line
   read(1010, *)
 
   !> scale of the lattice vectors
   read(1010, *) rscale

   read(1010, *) lattice(:, 1)
   read(1010, *) lattice(:, 2)
   read(1010, *) lattice(:, 3)
   lattice= lattice*rscale

   num_atoms_pertype=0
   !> only count Num_atoms, num_atomtypes
   if (lcount) then
      read(1010, *)firstcharacter
      !> character
      if (.not.(firstcharacter>='0' .and. firstcharacter<='9')) then
         read(1010, *, err=100, end=100) num_atoms_pertype 
      !> number
      else
         rewind(1010)
         do i=1,5
            read(1010, *)
         enddo
         read(1010, *, err=100, end=100) num_atoms_pertype 
      endif

      100 continue

      do i=1, 111
         if (num_atoms_pertype(i)==0) then
            num_atomtypes=i-1
            exit
         endif
      enddo
      num_atoms= sum(num_atoms_pertype)
   else
      read(1010, *)firstcharacter
      !> with atom name
      if (.not.(firstcharacter>='0' .and. firstcharacter<='9')) then
         with_atom_name=.true.
         rewind(1010)
         do i=1,5
            read(1010, *)
         enddo
         read(1010, *, err=101, end=101) atom_name(1:num_atomtypes)
         read(1010, *, err=101, end=101) num_atoms_pertype(1:num_atomtypes)
      !> without atom name
      else
         with_atom_name=.false.
         rewind(1010)
         do i=1,5
            read(1010, *)
         enddo
         read(1010, *, err=101, end=101) num_atoms_pertype(1:num_atomtypes)
      endif
      101 continue

      if (with_atom_name) then
         do i=1, num_atomtypes
            atom_types(i)= get_atomic_index(atom_name(i))
         enddo
      else
         do i=1, num_atomtypes
            atom_types(i)= i
         enddo
      endif

      !> read atoms position
      !> check whether there is a line showing "Selective dynamics"
      read(1010, *)firstcharacter
      if ((firstcharacter=='S' .or. firstcharacter=='s')) then
         ! skip one line
         read(1010, *) directorcart
      else
         directorcart= firstcharacter
      endif
    
      atom_positions=0._dp
      mag_positions=0._dp
      do i=1, Num_atoms
        !read(1010, *) atom_positions(:, i)
         read(1010,"(A180)") chat180
         read(chat180,*,iostat=ierr) atom_positions(:,i),mag_positions(:,i)
      enddo

      !> we need the fractional coordinates of atom's position.
      if ((directorcart=='C' .or. directorcart=='c')) then
         do i=1, Num_atoms
            call cartesian_to_direct(atom_positions(:, i), lattice)
         enddo
      endif

   endif
   close(1010)

   return
end subroutine read_poscar_

function get_atomic_index(atom_name)
   implicit none
   character(*) :: atom_name
   integer :: get_atomic_index, length, i

   length= 111
   do i=1,length
      if (upper(trim(adjustl(atom_name)))==upper(trim(adjustl(Atomic_names(i)))))then
         get_atomic_index= i
         exit
      else
         !> the given atomic name is not in the Periodic_table list
         get_atomic_index= 0
      endif
   enddo

   contains
   ! Capitalize each letter if it is lowecase
   function upper (str) result (string)
      implicit none
      character(*), intent(in) :: str
      character(len(str)) :: string
  
      integer :: ic, i
      character(26), parameter :: cap = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
      character(26), parameter :: low = 'abcdefghijklmnopqrstuvwxyz'
  
      string = str
      do i = 1, len_trim(str)
          ic = index(low, str(i:i))
          if (ic > 0) string(i:i) = cap(ic:ic)
      end do
   end function upper

end function get_atomic_index

subroutine write_msgout(num_sym, rotations, translations, gopa, tgopa, mtype, mtag, mresult)
   use parlib, only:dp,stdout4
   implicit none
   integer, intent(in) :: num_sym
   integer, intent(in) :: rotations(3, 3, num_sym)
   real(dp), intent(in) :: translations(3, num_sym)
   integer, intent(in) :: gopa(num_sym)
   integer, intent(in) :: tgopa(num_sym)
   character(len=*), intent(in) :: mresult
   integer :: i, j, k
   character(30), intent(out) :: mtype
   integer, intent(out) :: mtag
   real(dp) :: difftmp, difftmp1, difftmp2

   open(unit=stdout4, file='msgout.txt',status='unknown')
   write(stdout4,*)
   write(stdout4,'("###M ≡ G + AG, where M is a magnetic space group, G is its unitary part, and A is an antiunitary symmetry###")')
   write(stdout4,'(A44,A5,A20)') '###Magnetic moment geometric classification:',' ', mresult
   write(stdout4,*) 
   write(stdout4,'("#spg_symm :",I6)') num_sym
   k=0
   do i= 1,num_sym
      if (gopa(i)/=0) then
         k=k+1
         write(stdout4,'("#",I3,A8)') i,'unit'
         do j = 1, 2 
            write(stdout4, '( 3i3,F12.6)'),rotations(j,:, i),translations(j,i)
         end do
         write(stdout4, '( 3i3,F12.6,a6)'),rotations(3,:, i),translations(3,i),'+1'
      endif
      
      if (tgopa(i)/=0) then
         k=k+1
         write(stdout4,'("#",I3,A12)') i,'anti-unit'
         do j = 1, 2 
            write(stdout4, '( 3i3,F12.6)'),rotations(j,:, i),translations(j,i)
         end do
         write(stdout4, '( 3i3,F12.6,a6)'),rotations(3,:, i),translations(3,i),'-1'
      endif
   enddo  
   write(stdout4,*) 
   write(stdout4,'("#symm_mag,  #symm:",2I6)') k,num_sym
   write(stdout4,*) 
   
   difftmp2=0
   do i=1,num_sym
      if( sum(abs(rotations(:,:,i)- rotations(:,:,1)))<0.01 .and. tgopa(i)/=0) then
         difftmp2=1
      endif
   enddo
    difftmp= 0
    do i= 1,num_sym
      difftmp= difftmp+tgopa(i)
    enddo
    if (difftmp== 0) then   
    mtype='Type I (Fedorov)';mtag=1
    else
    difftmp1= 1
    do i= 1,num_sym
      difftmp1= difftmp1*tgopa(i)
    enddo
    if (difftmp1 /= 0) then   
    mtype='Type II (grey group)';mtag=2
    else
    if (tgopa(1)==0) then
    if (difftmp2/=0) then
    mtype='Type IV (klassengleiche)';mtag=4
    else 
    mtype='Type III (translationgleiche)';mtag=3
    endif
    endif
    endif
    endif

    write(stdout4, '( "Magnetic SG type : ",a)') mtype
    
    close(stdout4)
endsubroutine

subroutine find_eqatoms(num_atom,atom_types,num_sym,pos,mpos,rot,trans,symprec,eqv_map,eqv_pos)
   use parlib, only:dp, max_num_atom,max_num_sym
   implicit none
   integer , intent(in) :: num_atom, num_sym 
   integer , intent(in) :: atom_types(max_num_atom)
   integer , intent(in) :: rot(3,3,max_num_sym)
   real(dp), intent(in) :: pos(3,max_num_atom)
   real(dp), intent(in) :: mpos(3,max_num_atom)
   real(dp), intent(in) :: trans(3,max_num_sym)
   real(dp), intent(in) :: symprec
   integer , intent(out) :: eqv_map(2,max_num_atom)
   real(dp), intent(out) :: eqv_pos(6,max_num_atom)
   integer :: i, j, k, nclass
   real(dp) :: newpos(3), diff(3)
   logical :: leq
   
   eqv_map = 0
   eqv_pos = 0
   nclass = 0
   leq = .false.
   
   do i = 1, num_atom
     eqv_map(1,i) = i       
     eqv_pos(1:3,i) = pos(:,i)       
     eqv_pos(4:6,i) = mpos(:,i)       
     if (eqv_map(2,i) /= 0) cycle   
     if (atom_types(i) == 0 ) exit
     nclass = nclass + 1          
     eqv_map(2,i) = nclass          
   
     do j = i+1, num_atom        
       if (atom_types(j) == 0 ) exit
       if (atom_types(j) == atom_types(i)) then 
   
       leq = .false.
   
       do k = 1, num_sym
         newpos = matmul(rot(:,:,k), pos(:,i)) + trans(:,k)
         newpos = newpos - nint(newpos) 
         diff = newpos - pos(:,j)
         diff = diff - nint(diff)  
         if (all(abs(diff) < symprec)) then
           leq = .true.
           exit
         end if
       end do
   
       if (leq)  eqv_map(2,j) = nclass 
       end if
     end do
   end do
  
end subroutine find_eqatoms

subroutine find_eqmom(num_atom,num_sym,rot,trans,gopa,tgopa,symprec,eqv_map,eqv_pos,meqv_map)
   use mathlib, only: Matrix_Det
   use parlib, only:dp, max_num_atom,max_num_sym
   implicit none
   integer , intent(in) :: num_atom, num_sym 
   integer , intent(in) :: rot(3,3,max_num_sym)
   integer , intent(in) :: gopa(max_num_sym)
   integer , intent(in) :: tgopa(max_num_sym)
   real(dp), intent(in) :: symprec
   real(dp), intent(in) :: trans(3,max_num_sym)
   real(dp), intent(in) :: eqv_pos(6,max_num_atom)
   integer , intent(in) :: eqv_map(2,max_num_atom)
   integer , intent(out) :: meqv_map(2,max_num_atom)
   integer :: i, j, k, mclass, tmp33(3,3)
   real(dp) :: newpos(3), diff(3), newmpos(3), mdiff(3), det, tr, pos(3,num_atom), mvec(3,num_atom)
   logical :: leq
   
   
   meqv_map = 0
   mclass = 0
   leq = .false.
   meqv_map(1,:) = eqv_map(1,:)       
   

   do i = 1, num_atom
      mvec(:,i) = eqv_pos(4:6,i)
      pos(:,i)  = eqv_pos(1:3,i)
   end do

   do i = 1, num_atom
     if (meqv_map(2,i) /= 0) cycle   
     mclass = mclass + 1          
     meqv_map(2,i) = mclass          
   
     do j = i+1, num_atom        
       leq = .false.
       if (eqv_map(2,j) == eqv_map(2,i)) then 
   
       do k = 1, num_sym
          newmpos = matmul(rot(:,:,k), mvec(:,i))
          tmp33 = rot(:,:,k)
          call Matrix_Det(tmp33(:,:),3,det)
          if (gopa(k) == 0 .and. tgopa(k) == 0) cycle
          if (gopa(k)/=0) tr=1
          if (tgopa(k)/=0) tr=-1
          mdiff = newmpos - mvec(:,j)
          mdiff = mdiff - nint(mdiff)  
          newpos = matmul(rot(:,:,k), pos(:,i)) + trans(:,k)
          newpos = newpos - nint(newpos) 
          diff = newpos - pos(:,j)
          diff = diff - nint(diff)  
            if (all(abs(diff) < symprec) .and. all(abs(mdiff) < symprec)) then
              leq = .true.
              exit
            end if
       end do
   
       if (leq)  meqv_map(2,j) = mclass 
       end if
     end do
   end do
end subroutine find_eqmom

subroutine classify_magnetism(mfvec, num_atom, tol,mresult)
   use parlib, only:dp, max_num_atom,max_num_sym
   use mathlib, only: direct_to_cartesian
   implicit none
   integer, intent(in) :: num_atom
   real(dp), intent(in) :: mfvec(3,max_num_atom), tol
   character(len=*), intent(out) :: mresult
   
   integer :: i, n_use
   real(dp) :: mvec(3,num_atom), vecs(3,num_atom), ref(3), vi(3), vj(3), norm, normal(3)
   logical :: is_collinear, is_coplanar


   n_use = 0
   do i = 1, num_atom
     mvec(:,i) = mfvec(:,i)
     call direct_to_cartesian(mvec(:,i), lattice)
     if (sqrt(sum(mvec(:,i) ** 2)) > tol) then
       n_use = n_use + 1
       vecs(:,n_use) = mvec(:,i)
     end if
   end do
 
   if (n_use == 0) then
     mresult = 'no moment'
     return
   else if (n_use == 1) then
     mresult = 'collinear'
     return
   end if
 
   is_collinear = .true.
   ref = vecs(:,1)
   do i = 2, n_use
     vi = vecs(:,i)
     vj = [ ref(2)*vi(3) - ref(3)*vi(2), ref(3)*vi(1) - ref(1)*vi(3), ref(1)*vi(2) - ref(2)*vi(1) ]
     if (sqrt(sum(vj**2)) > tol) then
       is_collinear = .false.
       exit
     end if
   end do
   if (is_collinear) then
     mresult = 'collinear'
     return
   end if
 
   is_coplanar = .true.
   if (n_use < 3) then
     mresult = 'coplanar'
     return
   end if
 
   vi = vecs(:,2) - vecs(:,1)
   vj = vecs(:,3) - vecs(:,1)
   normal = [ vi(2)*vj(3) - vi(3)*vj(2), vi(3)*vj(1) - vi(1)*vj(3), vi(1)*vj(2) - vi(2)*vj(1) ]
   norm = sqrt(sum(normal**2))
   if (norm < tol) then
     mresult = 'collinear'
     return
   end if
   normal = normal / norm
 
   do i = 4, n_use
     vi = vecs(:,i) - vecs(:,1)
     if (abs(dot_product(normal, vi)) > tol) then
       is_coplanar = .false.
       exit
     end if
   end do
 
   if (is_coplanar) then
     mresult = 'coplanar'
   else
     mresult = 'non-coplanar'
   end if
    

end subroutine classify_magnetism


subroutine sort_eqv_map(eqv_map, eqv_pos, num_atom)
   use parlib, only:dp, max_num_atom,max_num_sym
   implicit none
   integer , intent(in) :: num_atom
   integer , intent(inout) :: eqv_map(2,max_num_atom)
   real(dp), intent(inout) :: eqv_pos(6,max_num_atom)
   
   integer  :: i, j, tmp_idx
   integer  :: idx(num_atom)
   integer  :: eqv_map_sorted(2, num_atom)
   real(dp) :: eqv_pos_sorted(6, num_atom)
   
   do i = 1, num_atom
      idx(i) = i
   end do
   
   do i = 1, num_atom - 1
      do j = i + 1, num_atom
         if (eqv_map(2, idx(j)) < eqv_map(2, idx(i))) then
            tmp_idx = idx(i)
            idx(i) = idx(j)
            idx(j) = tmp_idx
         end if
      end do
   end do
   
   do i = 1, num_atom
      eqv_map_sorted(:, i) = eqv_map(:, idx(i))
      eqv_pos_sorted(:, i) = eqv_pos(:, idx(i))
   end do
   do i = 1, num_atom
      eqv_map(:, i) = eqv_map_sorted(:, i)
      eqv_pos(:, i) = eqv_pos_sorted(:, i)
   end do

end subroutine sort_eqv_map

subroutine count_deg(num_atom,eqv_map,deg)
   use parlib, only:max_num_atom,max_num_sym
   implicit none
   integer , intent(in) :: num_atom
   integer , intent(in) :: eqv_map(2,max_num_atom)
   integer , intent(out) :: deg(2,num_atom)
   integer :: i, k
  
   deg = 0
   k = 1
   deg(2,k) = eqv_map(2,1)
   deg(1,k) = 1

   if (num_atom > 1) then
      do i = 2, num_atom
        if (eqv_map(2,i) == deg(2,k)) then
          deg(1,k) = deg(1,k) + 1
        else
          k = k + 1
          deg(2,k) = eqv_map(2,i)
          deg(1,k) = 1
        end if
      end do
  end if

end subroutine count_deg


subroutine write_wp(flname,num_atom,atom_types,eqv_map,eqv_pos)
   use parlib, only:dp,stdout3, max_num_atom,max_num_sym
   use mathlib, only: direct_to_cartesian
   implicit none
   character(len=*) , intent(in) :: flname
   integer , intent(in) :: num_atom
   integer , intent(in) :: atom_types(max_num_atom)
   integer , intent(inout) :: eqv_map(2,max_num_atom)
   real(dp), intent(inout) :: eqv_pos(6,max_num_atom)
   integer  :: i, j, deg(2,num_atom), tmp
   real(dp) :: mpos_c(3)
   character(len=20) :: fname

   
   
   fname=adjustl(flname)
   open(unit=stdout3, file=flname,status='unknown')
      if (fname(1:1) == 'M') then
         write(stdout3, '(a)'   )   '### MWyck. / Deg. / Types / Index /  Pos. /  Moment (cart)'
      else
         write(stdout3, '(a)'   )   '### Wyck. / Deg. / Types / Index / Pos. /  Moment (cart)'
         call sort_eqv_map(eqv_map, eqv_pos, num_atom)
      endif
      call count_deg(num_atom,eqv_map,deg)
      do i = 1, num_atom
         if (deg(1,i)==0) exit
         tmp = 1
         do j = i, num_atom
             mpos_c = eqv_pos(4:6, j)
             call direct_to_cartesian(mpos_c, lattice)
             if (deg(2,i)==eqv_map(2,j)) then
             if (tmp == 1) then
                write(stdout3, '(2I5,A7,I5,6f13.8)') eqv_map(2,j),deg(1,i), Atomic_names(atom_types(eqv_map(1,j))),eqv_map(1,j), eqv_pos(1:3,j),mpos_c(:)
                tmp = tmp+1
             else
                write(stdout3, '(A17,I5,6f13.8)') ' ',eqv_map(1,j), eqv_pos(1:3,j),mpos_c(:)
             endif 
             endif 
          end do
      end do
   close(stdout3)
end subroutine write_wp



subroutine write_mom(num_atom,eqv_map,eqv_pos)
   use parlib, only:dp,stdout3, max_num_atom,max_num_sym
   use mathlib, only: direct_to_cartesian
   implicit none
   integer , intent(in) :: num_atom
   integer , intent(inout) :: eqv_map(2,max_num_atom)
   real(dp), intent(inout) :: eqv_pos(6,max_num_atom)
   integer  :: i, j, deg(2,num_atom), tmp
   real(dp) :: mpos_c(3)

   
   
   open(unit=stdout3, file='MOMENT.dat',status='unknown')
      call count_deg(num_atom,eqv_map,deg)
      do i = 1, num_atom
         !if (deg(1,i)==0) exit
         tmp = 1
         do j = i, num_atom
             mpos_c = eqv_pos(4:6, j)
             call direct_to_cartesian(mpos_c, lattice)
             if (deg(2,i)==eqv_map(2,j)) then
             if (tmp == 1) then
                if (j/=1) then 
                   write(stdout3,*)
                   write(stdout3,*)
                endif
                write(stdout3, '(3f13.8)') mpos_c(:)
                tmp = tmp+1
             else
                write(stdout3, '(3f13.8)') mpos_c(:)
             endif 
             endif 
          end do
      end do
   close(stdout3)
end subroutine write_mom




subroutine write_poscar_msg(header61, mtag, num_atom, num_atomtypes, num_atoms_pertype, atom_types, eqv_pos, helium, tag, countsub)
   use parlib, only:dp,stdout3, max_num_atom,max_num_sym,tolerance1,Atomic_names
   use mathlib, only: direct_to_cartesian
   implicit none
   integer, intent(in) :: mtag, num_atom
   integer, intent(in) :: num_atomtypes
   integer, intent(in) :: num_atoms_pertype(111)
   integer, intent(in) :: atom_types(max_num_atom)
   
   integer :: i, j
   integer,intent(in) :: countsub
   integer,intent(in) :: tag(2*max_num_sym)
   character(61),intent(in) :: header61
   real(dp),intent(in) :: eqv_pos(6,max_num_atom)
   real(dp),intent(in) :: helium(3, max_num_sym)
   real(dp) :: mag_cart(3, num_atom), positions(3, num_atom), mpositions(3, num_atom) 
   
   real(dp) :: mpos_c(3)


   do i = 1, num_atom
      positions(:,i)  = eqv_pos(1:3,i)
      mpositions(:,i) = eqv_pos(4:6,i)
      mpos_c = eqv_pos(4:6, i)
      call direct_to_cartesian(mpos_c, lattice)
      mag_cart(:,i) = mpos_c(:)
   end do
   open(unit=stdout3, file='POSCAR_msg',status='unknown')
      write(stdout3, '(a)'   )   header61
      write(stdout3, '(f8.1)')    1.0
      write(stdout3, '(3f16.9)') (lattice(:, i),i=1,3)
   if (mtag/=2) then
      write(stdout3, '(99A4)')   (Atomic_names(atom_types(i)), i=1,num_atomtypes ) ,'He'
      write(stdout3, '(99i4)')   num_atoms_pertype(1:num_atomtypes),countsub
   else
      write(stdout3, '(99A4)')   (Atomic_names(atom_types(i)), i=1,num_atomtypes ) 
      write(stdout3, '(99i4)')   num_atoms_pertype(1:num_atomtypes)
   endif
      write(stdout3, '(a)'   )   'Direct'
   !!rhzhang 2024/4/24
   do i = 1, num_atomtypes
      if (i==1) then
      do j = 1,num_atoms_pertype(i)
         write(stdout3, "(3f12.8,$)") positions(:,j)
         if (sum(abs(mpositions(:,1:num_atoms_pertype(1)))).lt.1e-5) then
               write(stdout3, '(a)'   )   ' '
         ELSE
               write(stdout3, "('  # cart',3F9.5)") mag_cart(:,j)
         endif
      enddo
      else
         do j = sum(num_atoms_pertype(1:i-1))+1,sum(num_atoms_pertype(1:i))
            write(stdout3, "(3f12.8,$)") positions(:,j)
            if (sum(abs(mpositions(:,sum(num_atoms_pertype(:i-1))+1:sum(num_atoms_pertype(:i))))).lt.1e-5) then
               write(stdout3, '(a)'   )   ' '
            ELSE
               write(stdout3, "('  # cart',3F9.5)") mag_cart(:,j)
            endif
         enddo
      endif
   enddo
   !!zrh
   if (mtag/=2) then
   do j= 1,countsub  
      if (tag(j+countsub)==1) then
         write(stdout3, "(3f12.8,'  #',a3)") helium(:,j), '+1'
      else
         write(stdout3, "(3f12.8,'  #',a3)") helium(:,j), '-1'
      endif
   enddo
      write(stdout3, '(a)') ' '
   endif
      close(stdout3)
endsubroutine


endmodule context
