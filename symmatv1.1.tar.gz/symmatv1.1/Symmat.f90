!#-----------------------------------------------------------------------------!
! symmat version 1.1                                                           !
! chenhao liang @ IOP, Beijing 2025.5.1                                        !
! version 1.0 , 2025.5.10 : calculate the berry related tensors with IBZKPT    !
! version 1.1 , 2025.6.15 : process the ISYM!=1 or 2, for KPOINTS using KLINE  !
!#-----------------------------------------------------------------------------!

module  symm
   implicit none
   private

   integer, parameter :: dp = kind(1.0d0)

   integer, parameter :: NSYM =96
   integer  ,  save   :: IORD
   integer  ,  save   :: IZ(3,3,NSYM)
   real(dp) ,  save   :: DZ2(3,3,NSYM),DIIZ(3,3,NSYM)
   logical  ,  save   :: FL_inv(NSYM)
   real(dp) ,  save   :: TAU(3,NSYM)

   real(dp) ,  save   :: IBZk(3,1000000),IBZk_(3,1000000),FBZk(3,1000000)
   real(dp) ,  public, save   :: volume
   integer  , public,  save   :: nIBZk,nFBZk

   public   ::  IBZ2FK
   public   ::  ikk2fuk
   public   ::  get_KPT
   public   ::  get_KPT_nosym !ver 1.1 for kline
   public   ::  parse_band_argument
   public   ::  read_outcar_params

   CONTAINS

   subroutine get_KPT(nfst,NKPX,NKPY,NKPZ,isym_para) ! check KPOINTS type IBZKPT
      integer, intent(in)  :: nfst
      integer, intent(out) :: NKPX, NKPY, NKPZ
      logical, intent(out) :: isym_para
      integer :: ios
      real(dp) :: x1,x2,x3
      character(len=100) :: line,line_trimmed
      character(len=22) :: keyword
      character(len=1) :: first_char
      rewind(nfst)

      isym_para = .false.
      ! 跳过前两行
      read(nfst, '(A)', iostat=ios)
      read(nfst, '(A)', iostat=ios)

      ! 读取第三行，检查首字母是否是 'G' 或 'M'
      read(nfst, '(A)', iostat=ios) line
      if (ios /= 0) then
         print *, "Error: Unexpected end of file while reading third line of KPOINTS."
         stop
      end if
      line_trimmed = adjustl(trim(line))
      first_char = line_trimmed(1:1)! 获取首字母
      if (first_char == 'M' .or. first_char == 'm') then
         print *, "Error: MP sampling is not supported!"
         stop
      elseif ( first_char /= 'G' .and. first_char /= 'g') then
            if ( first_char /= 'L' .and. first_char /= 'l') then
               print *, "Error: Unrecognized k-point sampling type! Only Gamma or line mode are supported."
               stop
            endif
      end if

      ! GAMMA center
      if (first_char == 'G' .or. first_char == 'g') then
         isym_para = .true. !isym_para here is used to check kmesh type
         ! 读取第四行，解析NKPX, NKPY, NKPZ
         read(nfst, *, iostat=ios) NKPX, NKPY, NKPZ
         if (ios /= 0) then
            print *, "Error: Failed to read k-mesh values!"
            stop
         end if
         !write(*,'(A,3I5)')" Kmesh:  ",NKPX, NKPY, NKPZ

         ! 读取第五行并检查是否为 0 0 0 
         read(nfst, *, iostat=ios) x1, x2, x3
         if (ios /= 0) then
            print *, "Error: Unexpected end of file while reading fifth line of KPOINTS. The fifth line of KPOINTS must be '0 0 0'!"
            stop
         end if
         if (abs(x1) > 1E-6 .or. abs(x2) > 1E-6 .or. abs(x3) > 1E-6) then
            print *, "Error: The fifth line of KPOINTS must be '0 0 0'!"
            stop
         end if
         write(*,*) 'KPT: you are using G-centered mode'
      endif

      ! line mode
      if (first_char == 'L' .or. first_char == 'l') then
         isym_para = .false. !isym_para here is used to check kmesh type
         !In order to deal with Cartesian and reciprocal, it is convenient to read kline in outcar.scf by get_KPT_nosym
         write(*,*) 'KPT: you are using line mode'
         NKPX = 0
         NKPY = 0
         NKPZ = 0
      endif

   endsubroutine

   subroutine get_KPT_nosym(unit_num,NKPTS,fullK_dirct)
      implicit none
      integer, intent(in)  :: unit_num
      integer , intent(in) :: NKPTS
      real, intent(OUT) :: fullK_dirct(3,NKPTS)
      character(len=256)   :: line, dummy
      integer              :: ioss,ik_read
      logical              :: found_start
      found_start = .false.  ! 标记 "Following reciprocal coordinates:"
      ioss = 0               !
      ik_read = 0
      fullK_dirct = 0.0
      
      if (ioss /= 0) then
         write(*,*), "Error opening file OUTCAR.scf"
         return
      endif
      ! read
      do
         read(unit_num, '(A)', iostat=ioss) line
         if (ioss /= 0) exit  

         ! find "Following reciprocal coordinates:" 
         if (index(line, "Following reciprocal coordinates:") > 0) then
               found_start = .true.
         endif

         if (found_start) then
            ik_read = ik_read + 1
            if ((ik_read >=3) .and. (ik_read <=(NKPTS+2) )) then
               read(line, *, iostat=ioss) fullK_dirct(1,ik_read-2),fullK_dirct(2,ik_read-2),fullK_dirct(3,ik_read-2),dummy  ! read kpt
            endif
         endif
      end do
   end subroutine get_KPT_nosym


   subroutine IBZ2FK(nfst,NKPX,NKPY,NKPZ,NCHTS,NSYMM,isym_para)
         integer,intent(in)  :: nfst,NKPX,NKPY,NKPZ
         integer,intent(out) :: NCHTS(NKPX*NKPY*NKPZ)
         integer,intent(out) :: NSYMM(NKPX*NKPY*NKPZ)
         logical,intent(in)  :: isym_para
         
         real(dp) :: korg(3)

      character*120 :: chaps
      character*5   :: chtp5
      
      integer       :: itmp,jtmp,ierr, irot,ndeg(NKPX*NKPY*NKPZ),ndex(NKPX*NKPY*NKPZ+1)
      real(dp)      :: rtmp(8),rotmt(3,3)
      complex(dp)   :: crotmt(3,3),srotmt(2,2)
      !logical       :: FL0=.TRUE., FL1=.FALSE.  !! default:preserve time reversal, inversion symmetry
      logical       :: FL1=.FALSE.  !!  inversion symmetry
      real(dp)      :: br2(3,3),br4(3,3)
      logical       :: Find_irot
      integer       :: i,j,nx,ny,nz
      integer       :: NKPTS


         ! write(*,*)NKPTS,NKPX,NKPY,NKPZ
      ! set IORD,TAU,DZ2
         NKPTS = NKPX*NKPY*NKPZ
         rewind(nfst)

         FL_inv(:)=.FALSE.
         Find_irot = .FALSE.
      do 
         read(nfst, "(A90)", iostat=ierr) chaps
         if (ierr /= 0) exit  ! 读取错误或文件结束时退出循环
         chtp5 = chaps(1:5)
         if (chtp5 == 'Space') then
            Find_irot = .TRUE.
            exit
         end if
      end do
      
      if (.not. Find_irot) then
         write(*,*) 'ERROR: no Space group operators: (irot) in the OUTCAR.scf'
         stop
      end if

         read(nfst,*) 

      do irot=1,NSYM
         read(nfst,*,iostat=ierr)  itmp,rtmp
         if (ierr /= 0) exit
         IORD =irot
         TAU(:,irot)=rtmp(6:8)
         IF( abs( rtmp(1)+1.d0+rtmp(2)   ).lt.1.d-5 ) FL1=.TRUE. !inversion
         call Dmatrix(rnx=rtmp(3), rny=rtmp(4), rnz=rtmp(5), degree=-rtmp(2), twoja1=3, Dmat=crotmt)
         !call Dmatrix(rnx=rtmp(3), rny=rtmp(4), rnz=rtmp(5), degree=-rtmp(2), twoja1=2, Dmat=srotmt)
         rotmt=real(crotmt)
         IF(rtmp(1).lt. 1.d-2) rotmt=-rotmt
         IF(rtmp(1).lt. 1.d-2) FL_inv(irot)=.TRUE.
         DZ2(:,:,irot)= rotmt(:,:)
         !SU2(:,:,irot)=srotmt(:,:)
         !write(*,"(I5,9F6.2)") irot, DZ2(:,:,irot)
      enddo
         IF(irot==NSYM+1) STOP "ERROR in irot"
      !

      ! set IZ
      do 
         read(nfst,"(A90)") chaps
         chtp5=chaps(7:11)
         if(chtp5 =='direc' ) exit
      enddo
      do i=1,3
         read(nfst,*) br2(:,i),(br4(i,j),j=1,3)
      enddo
      volume = dabs(det3x3(br2))

      IZ=0; DIIZ=0._dp
      do irot=1,IORD
         write(23,"(I5)")  irot
         IZ(:,:,irot)= nint(matmul(matmul(br4, DZ2(:,:,irot)),br2))
         !DIZ(:,:,irot)=      matmul(matmul(br4, DZ2(:,:,irot)),br2)
         !IIZ(:,:,irot)=  matmul(matmul(          br4 ,transpose(DZ2(:,:,irot))),br4)
         DIIZ(:,:,irot)=  matmul(matmul(Transpose(br2),DZ2(:,:,irot)),Transpose(br4)) !IIZ transpose
         write(23,"(3F10.6)")  DIIZ(:,:,irot)
      enddo
      !

      ! read IBZk , fort.64 
      do 
         read(nfst,"(A90)") chaps
         chtp5=chaps(14:18)
         if(chtp5 =='recip' ) exit
      enddo

      do i=1,NKPTS
         read(nfst,*,iostat=ierr)  rtmp(1:3)
         if (ierr /= 0) exit
         nIBZk =i
         IBZk(:,i)=rtmp(1:3)
         write(64,"(I4,3F12.6)") i,IBZk(:,i)
      enddo
         korg(:)=IBZk(:,1)
      !

      ! rot*IBZk , fort.65---- 
         do irot=1,IORD
            IBZk_(:,1:nIBZk)=matmul(DIIZ(:,:,irot),IBZk(:,1:nIBZk))+0.00001_dp
         do i=1,nIBZk
            write(65,"(2I4,3F12.4)") i,irot, IBZk_(:,i)-floor(IBZk_(:,i))
         enddo
         enddo
         ! IF(.not. FL1 .and. FL0 ) THEN
         !    do irot=1,IORD
         !       IBZk_(:,1:nIBZk)=matmul(DIIZ(:,:,irot),-IBZk(:,1:nIBZk))+0.00000001_dp
         !    do i=1,nIBZk
         !       write(65,"(2I4,3F12.6)") i,-irot, IBZk_(:,i)-floor(IBZk_(:,i))
         !    enddo
         !    enddo
         ! ENDIF
      !!!

         !call execute_command_line ("sort -n -k3 -k4 -k5 fort.65|awk '{print $3,$4,$5}'|uniq -c >tmp22.txt")
         if(isym_para == .true.) then 
            call execute_command_line ("sort -n -k5 -k4 -k3 fort.65 >tmp11")
            call execute_command_line ("awk '{print $3,$4,$5}' tmp11 |uniq -c >tmp22")
         elseif(isym_para == .false.) then
            call execute_command_line ("cp fort.65 tmp11") 
            call execute_command_line ("awk '{print $3,$4,$5}' tmp11 |uniq -c >tmp22")
         endif

         open(547, file="tmp22", status="old" )
         ndeg=0;ndex=1
         do i=1,NKPTS
            read( 547,*,iostat=ierr) itmp,rtmp(1:3)
            if (ierr /= 0) exit
            nFBZk =i
            ndeg(i)=itmp
            if(i>1) ndex(i)=ndex(i-1)+ndeg(i-1)
            !write(*,"(2I5)") ndex(i),ndeg(i)
         enddo
         close(547)

         IF(nFBZk .ne. NKPTS) then
            do irot=1,IORD
               IBZk_(:,1:nIBZk)=matmul(DIIZ(:,:,irot),-IBZk(:,1:nIBZk))+0.00001_dp
            do i=1,nIBZk
               write(65,"(2I4,3F12.4)") i,-irot, IBZk_(:,i)-floor(IBZk_(:,i))
            enddo
            enddo
            if(isym_para == .true.) then 
               call execute_command_line ("sort -n -k5 -k4 -k3 fort.65 >tmp11")
               call execute_command_line ("awk '{print $3,$4,$5}' tmp11 |uniq -c >tmp22")
            elseif(isym_para == .false.) then
               call execute_command_line ("cp fort.65 tmp11") 
               call execute_command_line ("awk '{print $3,$4,$5}' tmp11 |uniq -c >tmp22")
            endif
         open(547, file="tmp22", status="old" )
         ndeg=0;ndex=1
         do i=1,NKPTS
            read( 547,*,iostat=ierr) itmp,rtmp(1:3)
            if (ierr /= 0) exit
            nFBZk =i
            ndeg(i)=itmp
            if(i>1) ndex(i)=ndex(i-1)+ndeg(i-1)
            !write(*,"(2I5)") ndex(i),ndeg(i)
         enddo
         close(547)
         IF(nFBZk .ne. NKPTS) STOP "ERROR in number of full BZ kpoints"
         ENDIF

         !write(*,"(2I5)") sum(ndeg), nIBZk*IORD

         !!!!! NCHTS(kfull index) = kIBZ index
         !     NSYMM(kfull index) = nsymm, with isymm *kIBZ index

         NCHTS(:) = 0
         NSYMM(:) = 0

         open(547, file="tmp11", status="old" )

         j=1

         do i=1,sum(ndeg)
         !write(*,*)i
            read( 547,*,iostat=ierr) itmp,jtmp
            if (ierr /= 0) exit
            if(i== ndex(j)) then
               !   write(*,"(4I4)") j,itmp,jtmp
               NCHTS(j)=itmp;NSYMM(j)=jtmp
               j=j+1
            endif
            
         enddo
         close(547)
   end subroutine IBZ2FK
   
   subroutine ikk2fuk(nbands,LL,symm_k,vmatk)
      integer, intent(in) :: nbands,LL,symm_k
      complex(dp), intent(inout) :: vmatk(nbands*nbands,3)

      complex(dp) :: vmatk_trans(3,nbands*nbands)

      real(dp) :: symm_k_mat(3,3)
      integer :: i,j
      !!!! LL=1 is a normal vector and even under T, e.g. E field ;
      !!!! LL=2 is a pseudo vector and odd  under T, e.g. spin    ;
      !!!! LL=3 is a normal vector and odd  under T, e.g. pi, k   ;
      !!!! LL=4 is a pseudo vector and even under T,              ;
      IF(LL .gt. 4) STOP "LL wzj"

     !!! time-reversal
      if(symm_k.gt.0) then
         symm_k_mat = DZ2(:,:,symm_k)
      else
         if( LL==2 .or. LL==3 ) then
            symm_k_mat = -DZ2(:,:,-symm_k)
         else
            symm_k_mat =  DZ2(:,:,-symm_k)
         endif
      endif

     !!! pseudo vector
      IF(FL_inv(abs(symm_k))) THEN
      if( LL==2 .or. LL==4 ) then
         symm_k_mat = -symm_k_mat
      endif
      ENDIF

      vmatk_trans = transpose(vmatk)
      vmatk_trans = matmul(symm_k_mat,vmatk_trans)
      vmatk = transpose(vmatk_trans)

      !!!bugfix-25.7; lch added.
      if (symm_k < 0) then
         if( LL==2 .or. LL==3 ) then
               vmatk = conjg(vmatk)
         endif
      ENDIF

   endsubroutine ikk2fuk

   function det3x3(A) result(det)
      real(dp), intent(in) :: A(3,3)
      real(dp) :: det

    det = A(1,1) * (A(2,2) * A(3,3) - A(2,3) * A(3,2)) &
        - A(1,2) * (A(2,1) * A(3,3) - A(2,3) * A(3,1)) &
        + A(1,3) * (A(2,1) * A(3,2) - A(2,2) * A(3,1))
   end function det3x3

   subroutine Dmatrix(ih, ik, il, rnx, rny, rnz, rtheta, rphi, degree, twoja1, Dmat)
      implicit none
      integer, intent(in), optional :: ih, ik, il
      real(dp), intent(in), optional :: rnx, rny, rnz
      real(dp), intent(in), optional :: rtheta, rphi
      real(dp), intent(in) ::  degree
      integer, intent(in) :: twoja1  ! equal to 2*J + 1
      complex(dp),dimension(twoja1,twoja1),intent(out) :: Dmat
      ! the key parameter for Dmatrix
      real(dp) :: nx, ny, nz
      real(dp) ::  omega
      ! complex(dp),dimension(aint(J)*2+1,aint(J)*2+1) :: Jx,Jy,Jz
      ! integer :: m
      complex(dp),parameter:: ci = (0.d0,1.d0)
      real*8     ,parameter:: PI = 3.141592653589793238462643383279d0
      real(dp) :: tmp
      real(dp) :: sqrt3
      real(dp) :: cosOmega_2, sinOmega_2
      real(dp) :: cos1omega, sin1omega, cos2omega, sin2omega, cos3omega, sin3omega, cos4omega, sin4omega
      complex(dp) :: exp2omega, exp_2omega, exp4omega, exp_4omega
      sqrt3 = dsqrt(3.0d0)
      if(present(ih).and.present(ik).and.present(il))then
         tmp = dsqrt(dble(ih)*dble(ih) + dble(ik)*dble(ik) + dble(il)*dble(il))
         nx = dble(ih)/tmp
         ny = dble(ik)/tmp
         nz = dble(il)/tmp
      else if(present(rtheta).and.present(rphi))then
         nx = dsin(rtheta)*dcos(rphi)
         ny = dsin(rtheta)*dsin(rphi)
         nz = dcos(rtheta)
      else if(present(rnx).and.present(rny).and.present(rnz))then
         tmp = dsqrt(rnx*rnx + rny*rny + rnz*rnz )
         if(abs(tmp-1.d0).gt.0.5d-6) then
            write(0,'(A,F16.10)')"WARMING!!! The nx, ny, nz input is not normailized: ",tmp
            write(0,*)"The program will normalize them now."
         end if
            nx = rnx/tmp
            ny = rny/tmp
            nz = rnz/tmp
      else
         write(*,*)" Please choose one of the three type of input: "
         write(*,*)" 1. h k l:"
         write(*,*)" 2. nx ny nz:"
         write(*,*)" 3. theta phi:"
      end if
      omega = dble(nint(degree))*PI/180.d0
      cosOmega_2 = dcos(omega/2.d0)
      sinOmega_2 = dsin(omega/2.d0)
      cos1omega = dcos(omega)
      sin1omega = dsin(omega)
      cos2omega = dcos(2.d0*omega)
      sin2omega = dsin(2.d0*omega)
      cos3omega = dcos(3.d0*omega)
      sin3omega = dsin(3.d0*omega)
      cos4omega = dcos(4.d0*omega)
      sin4omega = dsin(4.d0*omega)
      exp2omega = cmplx(cos2omega,sin2omega)
      exp_2omega = cmplx(cos2omega,-sin2omega)
      exp4omega = cmplx(cos4omega,sin4omega)
      exp_4omega = cmplx(cos4omega,-sin4omega)
      if(twoja1 == 2) then
         Dmat(1,1) = cmplx(cosOmega_2, -nz*sinOmega_2)
         Dmat(2,2) = cmplx(cosOmega_2, nz*sinOmega_2)
         Dmat(1,2) = cmplx(-ny, -nx)*sinOmega_2
         Dmat(2,1) = cmplx(ny, -nx)*sinOmega_2
      else if(twoja1 == 3) then
         Dmat(1,1) = nx**2+(1-nx**2)*cos1omega
         Dmat(2,2) = ny**2+(1-ny**2)*cos1omega
         Dmat(3,3) = nz**2+(1-nz**2)*cos1omega
         Dmat(1,2) = nx*ny*(1-cos1omega) - nz*sin1omega
         Dmat(2,1) = nx*ny*(1-cos1omega) + nz*sin1omega
         Dmat(1,3) = nx*nz*(1-cos1omega) + ny*sin1omega
         Dmat(3,1) = nx*nz*(1-cos1omega) - ny*sin1omega
         Dmat(2,3) = ny*nz*(1-cos1omega) - nx*sin1omega
         Dmat(3,2) = ny*nz*(1-cos1omega) + nx*sin1omega
      else if(twoja1 == 5) then
         Dmat(1,1) = 3.d0*ny**2*nx**2 + &
                     0.5d0*(exp_4omega + exp4omega)*(1-ny**2)*(1-nx**2) + &
                     0.5d0*(exp_2omega + exp2omega)*(nz**2*(1-nz**2)+(nx**2-ny**2)**2)
         Dmat(2,2) = 3.d0*ny**2*nz**2 + &
                     0.5d0*(exp_4omega + exp4omega)*(1-ny**2)*(1-nz**2) + &
                     0.5d0*(exp_2omega + exp2omega)*(nx**2*(1-nx**2)+(ny**2-nz**2)**2)
         Dmat(3,3) = 3.d0*nz**2*nx**2 + &
                     0.5d0*(exp_4omega + exp4omega)*(1-nz**2)*(1-nx**2) + &
                     0.5d0*(exp_2omega + exp2omega)*(ny**2*(1-ny**2)+(nx**2-nz**2)**2)
         Dmat(4,4) = 0.75d0*(nx**2-ny**2)**2 + &
                     0.125d0*(exp_4omega + exp4omega)*(4*nz**2+(nx**2-ny**2)**2) + &
                     0.5d0*(exp_2omega + exp2omega)*(nz**2*(1-nz**2) + 4*ny**2*nx**2)
         Dmat(5,5) = 0.25d0*(1-3*nz**2)**2 + &
                     1.5d0*(exp_2omega + exp2omega)*nz**2*(1-nz**2) + &
                     0.375d0*(exp_4omega + exp4omega)*(1-nz**2)**2

         Dmat(1,2) = -2.d0*ci*sin1omega*(ci*ny**3*cos1omega + ci*ny*(1-ny**2)*cos3omega + &
                                          nx*nz*( 3.d0*ci*ny**2*sin1omega+ci*(1-ny**2)*sin3omega))
         Dmat(2,1) =  2.d0*ci*sin1omega*(ci*ny**3*cos1omega + ci*ny*(1-ny**2)*cos3omega + &
                                          nx*nz*(-3.d0*ci*ny**2*sin1omega-ci*(1-ny**2)*sin3omega))
         Dmat(2,3) = -2.d0*ci*sin1omega*(ci*nz**3*cos1omega + ci*nz*(1-nz**2)*cos3omega + &
                                          nx*ny*( 3.d0*ci*nz**2*sin1omega+ci*(1-nz**2)*sin3omega))
         Dmat(3,2) =  2.d0*ci*sin1omega*(ci*nz**3*cos1omega + ci*nz*(1-nz**2)*cos3omega + &
                                          nx*ny*(-3.d0*ci*nz**2*sin1omega-ci*(1-nz**2)*sin3omega))
         Dmat(1,3) =  2.d0*ci*sin1omega*(ci*nx**3*cos1omega + ci*nx*(1-nx**2)*cos3omega + &
                                          ny*nz*(-3.d0*ci*nx**2*sin1omega-ci*(1-nx**2)*sin3omega))
         Dmat(3,1) = -2.d0*ci*sin1omega*(ci*nx**3*cos1omega + ci*nx*(1-nx**2)*cos3omega + &
                                          ny*nz*( 3.d0*ci*nx**2*sin1omega+ci*(1-nx**2)*sin3omega))

         Dmat(1,4) = -ci*sin1omega*(ci*nz*(3.d0-nz**2)*cos1omega + ci*nz*(1+nz**2)*cos3omega - &
                                       4.d0*ci*nx*ny*(ny**2-nx**2)*sin1omega**3)
         Dmat(4,1) =  ci*sin1omega*(ci*nz*(3.d0-nz**2)*cos1omega + ci*nz*(1+nz**2)*cos3omega + &
                                       4.d0*ci*nx*ny*(ny**2-nx**2)*sin1omega**3)
         Dmat(1,5) = -2.d0*sqrt3*sin1omega**2*(nx*ny*(1.d0-nz**2) + nx*ny*(1+nz**2)*cos2omega - &
                                                   nz*(ny**2-nx**2)*sin2omega)
         Dmat(5,1) = -2.d0*sqrt3*sin1omega**2*(nx*ny*(1.d0-nz**2) + nx*ny*(1+nz**2)*cos2omega + &
                                                   nz*(ny**2-nx**2)*sin2omega)

         Dmat(2,4) = 1.5d0*(nx**2 - ny**2)*ny*nz + ny*nz*(2.d0*ny**2 - 2.d0*nx**2 - 1.d0)*cos2omega + &
                     0.5d0*ny*nz*(2.d0*nx**2 + nz**2 + 1.d0)*cos4omega - &
                     nx*( 2.d0*ny**2 - nz**2 + (1.d0 - 2.d0*ny**2 + nz**2)*cos2omega)*sin2omega
         Dmat(3,4) = 1.5d0*(nx**2 - ny**2)*nx*nz + nx*nz*(4.d0*ny**2 + 2.d0*nz**2 - 1.d0)*cos2omega - &
                     0.5d0*nx*nz*(2.d0*ny**2 + nz**2 + 1.d0)*cos4omega - &
                     ny*( 2.d0*nx**2 - nz**2 + (-1.d0 + 2.d0*ny**2 + 3.d0*nz**2)*cos2omega)*sin2omega
         Dmat(4,2) = 1.5d0*(nx**2 - ny**2)*ny*nz + ny*nz*(2.d0*ny**2 - 2.d0*nx**2 - 1.d0)*cos2omega + &
                     0.5d0*ny*nz*(2.d0*nx**2 + nz**2 + 1.d0)*cos4omega + &
                     nx*( 2.d0*ny**2 - nz**2 + (1.d0 - 2.d0*ny**2 + nz**2)*cos2omega)*sin2omega
         Dmat(4,3) = 1.5d0*(nx**2 - ny**2)*nx*nz + nx*nz*(4.d0*ny**2 + 2.d0*nz**2 - 1.d0)*cos2omega - &
                     0.5d0*nx*nz*(2.d0*ny**2 + nz**2 + 1.d0)*cos4omega + &
                     ny*( 2.d0*nx**2 - nz**2 + (-1.d0 + 2.d0*ny**2 + 3.d0*nz**2)*cos2omega)*sin2omega

         Dmat(2,5) = 2.d0*ci*sqrt3*(nz**2 + (1 - nz**2)*cos2omega)*sin1omega*ci*(nx*cos1omega - ny*nz*sin1omega)
         Dmat(3,5) =-2.d0*ci*sqrt3*(nz**2 + (1 - nz**2)*cos2omega)*sin1omega*ci*(ny*cos1omega + nx*nz*sin1omega)
         Dmat(5,3) = 2.d0*ci*sqrt3*(nz**2 + (1 - nz**2)*cos2omega)*sin1omega*ci*(ny*cos1omega - nx*nz*sin1omega)
         Dmat(5,2) =-2.d0*ci*sqrt3*(nz**2 + (1 - nz**2)*cos2omega)*sin1omega*ci*(nx*cos1omega + ny*nz*sin1omega)

         Dmat(4,5) = -sqrt3*sin1omega**2*(nx**4 - ny**4 + (nx**2 - ny**2)*(1.d0 + nz**2)*cos2omega - &
                                                4.d0*nx*ny*nz*sin2omega)
         Dmat(5,4) = -sqrt3*sin1omega**2*(nx**4 - ny**4 + (nx**2 - ny**2)*(1.d0 + nz**2)*cos2omega + &
                                                4.d0*nx*ny*nz*sin2omega)
      else
         write(*,*) " This subroutine can only deal with J = 1/2, 1, 2 !!! "
      end if
   end subroutine Dmatrix


   subroutine parse_band_argument(arg_char, select_bands_, num_select_)
      implicit none
      character(len=*), intent(in) :: arg_char
      integer, intent(out) :: select_bands_(1000)  ! 固定长度为1000
      integer, intent(out) :: num_select_
      integer :: i, band, pos, ierr
      character(len=255) :: tmp, range_str
      integer :: count
      integer :: start_band, end_band
      character(len=255) :: start_str, end_str

      ! 初始化
      num_select_ = 0
      select_bands_ = 0  ! 将数组初始化为0

      ! 初始化错误标志
      ierr = 0

      ! 检查是否是带范围参数，例如 -nb 5:15
      if (index(arg_char, ':') .ne. 0) then
         ! 提取带范围字符串
         read(arg_char, '(A)') range_str

         ! 找到":"位置
         pos = index(range_str, ':')
         if (pos == 0) then
            print *, 'Invalid band range format. Expected: start_band:end_band'
            stop
         end if

         ! 将:前后部分分开，分别提取 start_band 和 end_band
         start_str = range_str(1:pos-1)
         end_str = range_str(pos+1:)

         ! 解析 start_band 和 end_band
         read(start_str, '(I5)', IOSTAT=ierr) start_band
         if (ierr /= 0) then
            print *, 'Error reading start_band'
            stop
         end if

         read(end_str, '(I5)', IOSTAT=ierr) end_band
         if (ierr /= 0) then
            print *, 'Error reading end_band'
            stop
         end if

         if (start_band > end_band) then
            print *, 'Invalid band range: start > end'
            stop
         end if

         ! 分配选择带宽
         do i = start_band, end_band
            select_bands_(i - start_band + 1) = i
         end do
         num_select_ = end_band - start_band + 1
      else
         print *, 'Error reading band number'
         stop
      end if

   end subroutine parse_band_argument

   subroutine read_outcar_params(unit_num, spin_degeneracy,lnoncollinear,isym_para,KPTdim)
      implicit none
      integer, intent(in)  :: unit_num
      integer :: ispin
      integer :: isym
      logical , intent(OUT) :: lnoncollinear
      logical , intent(OUT) :: spin_degeneracy
      logical , intent(OUT) :: isym_para! ver  1.1
      integer , intent(OUT) :: KPTdim
      character(len=256)   :: line, dummy
      integer              :: ioss
      logical              :: found_start,found_start_array
      spin_degeneracy = .false.
      found_start = .false.  ! 标记 "Startparameter for this run:"
      found_start_array = .false. ! 标记 "Dimension of arrays:"
      ispin = 1              ! 
      lnoncollinear = .false.
      ioss = 0               !
      isym= 0                ! ver 1.1 IF/NOT we use the symmetry
      isym_para = .false.
      KPTdim = 1

      if (ioss /= 0) then
         write(*,*), "Error opening file OUTCAR.scf"
         return
      endif
      ! read outcar, ISPIN,NONCOLLINEAR,ISYM
      do
         read(unit_num, '(A)', iostat=ioss) line
         if (ioss /= 0) exit  

         ! find "Startparameter for this run:" 
         if (index(line, "Startparameter for this run:") > 0) then
               found_start = .true.
         endif

         if (found_start) then
               if (index(line, "ISPIN") > 0) then
                  read(line, *, iostat=ioss) dummy, dummy, ispin  ! read ISPIN ///   ISPIN  =      1    spin polarized calculation?
               elseif (index(line, "LNONCOLLINEAR") > 0) then
                  read(line, *, iostat=ioss) dummy, dummy, lnoncollinear  ! read LNONCOLLINEAR    ///  LNONCOLLINEAR =      F non collinear calculations
               elseif (index(line, "ISYM") > 0) then
                  read(line, *, iostat=ioss) dummy, dummy, isym  ! read ISYM /// -1,0-nonsym 1-usesym 2-fastsym
               endif
         endif

         ! find "Dimension of arrays:" 
         if (index(line, "Dimension of arrays:") > 0) then
               found_start_array = .true.
         endif
         if (found_start_array) then
            if (index(line,"NKPTS") > 0) then
               read(line, *, iostat=ioss) dummy,dummy, dummy, KPTdim  ! read: k-points  NKPTS =  KPTdim 
               found_start_array = .false.
            endif
         endif

      end do


      if (lnoncollinear == .true. ) then
         spin_degeneracy =  .false. 
      else
         if (ISPIN  == 2) then
            spin_degeneracy =  .false. 
         else
            spin_degeneracy = .true.
         endif
      endif

      if (isym > 0) then 
         isym_para = .true.
      else
         isym_para = .false.
      endif

   end subroutine read_outcar_params

end module symm

program berry_curvature 
   use symm
    implicit none

    integer    , parameter :: dp = kind(1.0d0)
    complex(dp), parameter :: zi = cmplx(0._dp, 1._dp,dp)
    complex(dp), parameter :: czero= cmplx(0._dp, 0._dp,dp)
    complex(dp), parameter :: cone = cmplx(1._dp, 0._dp,dp)
    real(dp)   , parameter :: e2_h=3874.04614_dp ! simen/cm

      real(dp),parameter :: pi = 3.1415926535897932
      real(dp),parameter :: e_ele = 1.6021766208D-19
      real(dp),parameter :: hbar = 6.582119569*1e-16 !# in the unit of eV*s
      real(dp),parameter :: abseps = 8.8541878128*1e-12
      real(dp),parameter :: Ang = 1.00D-10
      real(dp),parameter :: clight  = 299792458


      REAL(dp), PARAMETER :: AUTOA=0.529177249d0!< 1 Bohr in Angstroem
      REAL(dp), PARAMETER:: RYTOEV=13.605826d0 !< 1 Ry in Ev
      !time
      integer :: start_time, cur_time
      integer :: rate = 1
      real(8) :: avg_time, remain_time
!_____________________________________________________________________________!
!   use the units of VASP
!_____________________________________________________________________________!
!> electron charge divided by 4*pi times the permittivity of free space
!>         in atomic units this is just e^2
!> \f( \frac{e^2}{4 \pi \epsilon_0} \f)
      REAL(dp), PARAMETER:: FELECT = 2*RYTOEV*AUTOA
!> electron charge divided by the permittivity of free space
!>         in atomic units this is just 4 pi e^2
!> \f( \frac{e^2}{\epsilon_0} \f)
      REAL(dp), PARAMETER :: EDEPS = 4*PI*FELECT
!> reduced planck constant squared divided by 2 times the electron mass
!> \f( \frac{\hbar^2}{2 m_e} \f)
      REAL(dp), PARAMETER :: HSQDTM = RYTOEV*AUTOA*AUTOA
!> then m_e = 1/2 * 1/(HSQDTM)* hbar^2
      REAL(dp), PARAMETER :: m_e = 0.50d0 * hbar * hbar /  HSQDTM 
!> reduced planck constant squared divided by 2 times the electron mass and Bohr
!> \f( \frac{\hbar^2}{2 m_e AUTOA} \f)
      REAL(dp), PARAMETER :: H2DTMB = RYTOEV*AUTOA
!> reduced planck constant squared divided by 2 times the electron mass and Bohr^2
!> \f( \frac{\hbar^2}{2 m_e AUTOA^2} \f)
      REAL(dp), PARAMETER :: H2DTMB2 = RYTOEV

    integer :: lda, ierr
    integer :: NKPTS,ik,ikk,ii,dir,nnbb
    integer :: NKPX,NKPY,NKPZ
    real(dp)   , allocatable  :: eig(:,:),FBZk(:,:)
    complex(dp), allocatable  :: Atmp(:,:),Atmp2(:,:),Atmp3(:,:)
    complex(dp), allocatable  :: vmat(:,:,:),smat(:,:,:),Jmat(:,:,:,:)
    complex(dp), allocatable  :: DHDk(:,:,:),DHDkdag(:,:,:),Js(:,:,:,:),DHDk_E(:,:,:)
    !--------------berry related---------------!
    REAL(dp), allocatable  :: dielectric_kmesh(:,:),berry_curvature_select(:,:,:),spn_or_orb_berry_select(:,:,:,:),berry_tensor_kmesh(:,:,:),orbital_magnetism_kmesh(:,:,:)
    integer :: select_bands(1000)
    integer :: num_select
    real(dp) :: dielectric_constant(6) = 0.0
    real(dp) :: AHE_conductance(3) = 0.0
    real(dp) :: SHE_conductance(3,3) = 0.0
    real(dp) :: OHE_conductance(3,3) = 0.0
    complex(dp) :: Omega
    integer  :: i,j,iv,oxyz,nocc,m,n,tagm,tagn,tagspn,tagorb,tagnb,p,q,tagtest
    real(dp) ::  sigma_tensor_tmp(3,3),mu,berry_tensor_tmp(3,4)
    real(dp) :: eval(80000), emn, eqn,eqm
    integer, allocatable :: NCHTS(:),NSYMM(:)
    real(dp) :: coeff_eps,coeff_orbitmag, coeff_berry
    logical :: spin_degeneracy,lnoncollinear,isym_para
    integer :: KPTdim  !Dimension of arrays, k-points in outcar

    character(len=100)::out_dielectric = 'dielectric_constants.dat'
    character(len=100)::out_berry_AHE= 'berry_0.dat'
    character(len=100)::out_spin_berry_SHE_x= 'berry_1.dat'
    character(len=100)::out_spin_berry_SHE_y= 'berry_2.dat'
    character(len=100)::out_spin_berry_SHE_z= 'berry_3.dat'
    character(len=100)::out_orbital_berry_OHE= 'orbital_berry_kmesh_and_OHE.dat'!TODO: Not yet tested — placeholder implementation.
    character(len=100)::out_berry_select= 'select_bands_berry.dat'
    character(len=100)::out_spin_berry_select = 'select_bands_spin_berry.dat'
    character(len=100)::out_orbital_mag_select = 'select_bands_orbital_magnetism.dat'!TODO: Not yet tested — placeholder implementation.
    character(len=100)::out_orbital_berry_select = 'select_bands_orbital_berry.dat'!TODO: Not yet tested — placeholder implementation.

     ! command argument
   integer :: narg,iarg,lens,stat
   character(len=50) :: arg,cmd
   complex(dp), allocatable :: vmat_IBZ(:,:,:,:)
   complex(dp), allocatable :: smat_IBZ(:,:,:,:)
   complex(dp), allocatable :: omat_IBZ(:,:,:,:)
   real, allocatable :: fullK_dirct(:,:)
   real(dp) :: nkx,nky,nkz
   integer :: dir1(6) = (/ 1,1,1,2,2,3 /)
   integer :: dir2(6) = (/ 1,2,3,2,3,3 /) 
   integer :: dir3(3) = (/ 2,3,1 /) 
   integer :: dir4(3) = (/ 3,1,2/)
   integer :: nx,ny,nz,isymm
      ! dir1di2 are xx xy xz yy yz zz
      ! dir2dir3 are xy yz zx
      NKPX = 1
      NKPY = 1
      NKPZ = 1
      mu=0._dp
      nocc=0 
      oxyz=0
      tagm=0;tagn=0;tagorb=0;tagspn=1;tagnb=0;tagtest=0
      select_bands(1) = 1
      select_bands(2) = 2
      num_select = 2

      call get_command(cmd)
      write(*,*) '# Current command : ',cmd
      narg = command_argument_count()
     !write(*,*) '# Argument count : ',narg
      IF(narg==0) then
          write(*,"('Please input the correct command:')")
          write(*,"('like: -mu $mu -noe $nocc' )  ")
          STOP
      ELSE
      iarg = 1
      do while(.true.) 
         call get_command_argument(iarg, arg,lens,stat)
         IF(len_trim(arg) == 0)  EXIT
         
         IF(trim(arg)=='-mu') THEN
           iarg = iarg +1; call get_command_argument(iarg, arg,lens,stat) !tmp
           read(arg,*) mu!; print*, sgn
           tagm=1
         ELSEIF(trim(arg)=='-noe') THEN
           iarg = iarg +1; call get_command_argument(iarg, arg,lens,stat) !tmp
           read(arg,*) nocc  !!; print*, ver_n
           tagn=1
         ELSEIF (trim(arg) == '-nb') THEN
            iarg = iarg + 1
            call get_command_argument(iarg, arg, lens, stat)
            call parse_band_argument(arg, select_bands, num_select)            
            write(*,'(A,1I10)') ' Number of selected bands: ', num_select
            write(*,*) 'Selected bands: ', select_bands(1:num_select)
            tagnb=1
         ELSEIF(trim(arg)=='-spin') THEN
           iarg = iarg +1; tagspn = 1 ; tagorb = 0
         ! ELSEIF(trim(arg)=='-orb') THEN
         !   iarg = iarg +1; tagorb = 1 ; tagspn = 0
         ELSEIF(trim(arg)=='-test') THEN
           iarg = iarg +1; tagtest = 1 
         ELSE
          write(*,"('Please input $mu (or $nocc) by the command below:')")
          write(*,"('###$: omega-mu $mu (-noe $nocc) -nb $band1:$band2')  ")
          STOP
         ENDIF
         iarg = iarg +1
         !write(*,*) 'Selected iarg', iarg
      end do
      ENDIF

      IF(tagm*tagn==1) THEN
         STOP '###$: omega-mu $mu or $ omega -n $nocc ' !only one is  needed
      ENDIF

      IF(tagm==0 .and. tagn==0) THEN
         STOP '###$: omega-mu $mu or $ omega -n $nocc ' ! anyone is needed
      ENDIF
    
   !----------if/not using the noncollinear calculation? using symmetry? k point type?
   lnoncollinear = .false. 
   isym_para = .false.
   open(1045, file='OUTCAR.scf', status="old" )
   call read_outcar_params(1045,spin_degeneracy,lnoncollinear,isym_para,KPTdim) !Here, isym_para is not used. Prepare for future modifications.
   close(1045)
   if (lnoncollinear == .false. ) then
      tagspn = 0
   endif
   open(1045, file='KPOINTS', status="old" )
   call get_KPT(1045,NKPX,NKPY,NKPZ,isym_para) ! read kpoint type (isym_para). if is is gamma centered ,read nkx nky nkz
   close(1045)

   !----------read the kpt, prepare the IBZ to FBZ
   if (isym_para == .true.) then
      allocate(NCHTS(NKPX*NKPY*NKPZ),NSYMM(NKPX*NKPY*NKPZ))
      NCHTS=0; NSYMM=0
      open(1045, file='OUTCAR.scf', status="old" )
      call IBZ2FK(1045,NKPX,NKPY,NKPZ,NCHTS,NSYMM,isym_para)
      NKPTS = NKPX*NKPY*NKPZ
      if (NKPTS == 0) then
         write(*,*) 'Error: wrong k-mesh values! Find 0 in some directions'
         stop
      endif
      close(1045)
      ! allocate full kpoint list in dirct basis
      open(1045, file='tmp22', status="old" )
      allocate(fullK_dirct(3,NKPTS),stat=ierr)
      fullK_dirct = 0
      do i=1,NKPTS
         read(1045,*) ii,fullK_dirct(1,i),fullK_dirct(2,i),fullK_dirct(3,i)
      enddo
      close(1045)
      ! symm on
      write(*,'(a)') " Symmetry ON"

   elseif (isym_para == .false.) then
      ! allocate full kpoint list in dirct basis , without symmetry
      allocate(fullK_dirct(3,KPTdim),stat=ierr)
      fullK_dirct = 0.0
      open(1045, file='OUTCAR.scf', status="old" )
      call get_KPT_nosym(1045,KPTdim,fullK_dirct)
      !---------just reuse these parameter
      NKPTS = KPTdim
      NKPX = NKPTS; NKPY = 1; NKPZ = 1
      nIBZk = NKPTS
      !---------set volume = 1 for Kline
      volume = 1.0 
      if (NKPTS == 0) then
         write(*,*) 'Error: NKPT should not be 0'
         stop
      endif
      close(1045)
      ! symm on
      write(*,'(a)') " Symmetry OFF"
   endif

   !---------------------SET THE COEFF for dielectric constants, AHE, SHE--------------------
   if (isym_para == .true.) coeff_eps = ( 2*4*pi*FELECT ) * ( 4*H2DTMB*H2DTMB ) /(volume*NKPTS)   ! after this coeff , we actually in the unit of epsilon_0 (permittivity of free space)
   if (isym_para ==.false.) coeff_eps = ( 2*4*pi*FELECT ) * ( 4*H2DTMB*H2DTMB ) !in the unit of (permittivity of free space * ang^3)
   if (spin_degeneracy == .true.) then
      if (isym_para == .true.) coeff_eps = ( 2*4*pi*FELECT ) * ( 2 * 4*H2DTMB*H2DTMB ) /(volume*NKPTS)   ! with spin_degeneracy after this coeff , we actually in the unit of epsilon_0 (permittivity of free space)
      if (isym_para ==.false.) coeff_eps = ( 2*4*pi*FELECT ) * ( 2 * 4**H2DTMB*H2DTMB ) !in the unit of (permittivity of free space * ang^3)
   endif
   !coeff_orbitmag = - H2DTMB2 ! after this coeff , we actually in the unit of mu_B (Bohr magneton = e*hbar/（2 m_e）)
    coeff_berry = - 2 * 4 * H2DTMB * H2DTMB ! after this coeff , we actually in unit ang^2 ! after this coeff , we actually in the unit: ang^2    ！ note that: the vmat(fort.1317) output by vasp2mat is in hbar/bohr (it is momentum matrix)
   !-----------------------------------------------------------------------------------------
   if(isym_para == .true.) then
      write(*,*) "nKPT in DFT:",KPTdim,"  nIBZk:",nIBZk,"  nFBZk:",NKPTS
   elseif(isym_para == .false.) then
      write(*,*) "nKPT in DFT:",KPTdim,"  ntotk:",nIBZk ! for nosymm calcu: nIBZK = nFKPT
   endif

   write(*,"(a)")"----Reading vmat eigmat ..."
   ! eig
    open( 1045, file='fort.1315', status="old" )
     read(1045,*) lda, nIBZk; IF(lda>80000) STOP "total bands is too large"
     allocate(eig(lda,nIBZk),stat=ierr); eig=0._dp
     do ik=1,nIBZk
     read(1045,"(I5,80000E14.6)") ii,eig(:,ik)
     enddo
    close(1045)
   ! smat
   if (tagspn == 1) then
    allocate(smat_IBZ(lda,lda,3,nIBZk));smat_IBZ=cmplx(0._dp,0._dp,dp)
    open(1045, file='fort.1316', status="old" )
    read(1045,*)
    do i=1,nIBZk
       read(1045, *) 
       read(1045, "(8E14.6)") smat_IBZ(:, :, 1, i)
       read(1045, "(8E14.6)") smat_IBZ(:, :, 2, i)
       read(1045, "(8E14.6)") smat_IBZ(:, :, 3, i)
    enddo
    close(1045)
   endif
   ! vmat
    allocate(vmat_IBZ(lda,lda,3,nIBZk));vmat_IBZ=cmplx(0._dp,0._dp,dp)
    open(1045, file='fort.1317', status="old" )
    read(1045,*)
    do i=1,nIBZk
       read(1045, *) 
       read(1045, "(8E14.6)") vmat_IBZ(:, :, 1, i)
       read(1045, "(8E14.6)") vmat_IBZ(:, :, 2, i)
       read(1045, "(8E14.6)") vmat_IBZ(:, :, 3, i)
    enddo
    close(1045)
   ! and check the total bands and given bands
   if ((tagn == 1) .and. (nocc >= lda)) then
      write(*,*)"ERROR!! : the index of max_occ_band is equal to / (larger than) your number_of_total_bands. The first band in this program is the bstart in vasp2mat."
      stop
   endif
   if (lda < select_bands(num_select) ) then 
      write(*,*)"ERROR!! : your number_of_total_bands is smaller than your max_select_band. The first band in this program is the bstart in vasp2mat."
      stop
   endif
   write(*,*) "Total bands:",lda,"  spin_degeneracy:", spin_degeneracy
   write(*,"(a)")"----done"

    open( 3001, file='eig.dat ', status="unknown")
    open( 3003, file='vmat.dat', status="unknown")
    write(3001,'(2I10,A)') lda,NKPTS," : eig"!KPOINTS%NKPTS-1
    write(3003,'(2I10,A)') lda,NKPTS," :vmat"!KPOINTS%NKPTS-1
   if (tagspn == 1) then
    open( 3002, file='smat.dat', status="unknown")
    write(3002,'(2I10,A)') lda,NKPTS," :smat"!KPOINTS%NKPTS-1
   ENDIF
   if (tagtest == 1) then
    write(3009,'(a)') '# kx ky kz eig(2)-eig(1) <1|Pi_x|2>   <1|Pi_y|2>   <1|Pi_z|2>' !test
   endif

   !
    allocate(Atmp(lda,lda),Atmp2(lda,lda),stat=ierr)
    allocate(DHDk(lda,lda,3),DHDk_E(lda,lda,3),stat=ierr)
    allocate(DHDkdag(lda,lda,3),stat=ierr)
    allocate(Js(lda,lda,3,0:3),stat=ierr)
    allocate(Jmat(lda,lda,3,0:3),smat(lda,lda,3),vmat(lda,lda,3),stat=ierr)
    allocate(dielectric_kmesh(6,NKPTS),berry_curvature_select(3,num_select,NKPTS),spn_or_orb_berry_select(3,3,num_select,NKPTS),orbital_magnetism_kmesh(3,num_select,NKPTS))
    allocate(berry_tensor_kmesh(3,4,NKPTS))

   eval(:)=0._dp
   write(*,'(a)') "Now, start the main loop"
   vmat=czero;smat=czero
   dielectric_kmesh = 0.00_dp
   berry_curvature_select = 0.00_dp
   spn_or_orb_berry_select = 0.00_dp
   orbital_magnetism_kmesh = 0.00_dp
   !-----if we calculate the orbital hall effect the "angular momentum" is changed from spin to orbit--------!
   if (tagorb == 1) then
      smat_IBZ = - omat_IBZ !(:,:,1:3,:) ; omat in [\mu_B] --> L = -\hbar/(g_L * \mu_B) --> L = - omat     in [\hbar]
   endif

   ! main-loop
   call system_clock(start_time, rate) !timer
   do ik=1,NKPTS ! not optimized at all; it’s just a functional version XD
      if (ik == 5) then
         call system_clock(cur_time)
         avg_time = real(cur_time - start_time, 8) / ik
         remain_time = avg_time * (NKPTS - ik) /10000.0
         write(*,'(A,I6,A,I6,A,F20.2,A)') "Processed k = ", ik, " / ", NKPTS, "    Remaining time: ", remain_time, " sec (updates every 100 kpts)"
      end if
      if (mod(ik, 100) == 0) then
         call system_clock(cur_time)
         avg_time = real(cur_time - start_time, 8) / ik
         remain_time = avg_time * (NKPTS - ik) /10000.0
         write(*,'(A,I6,A,I6,A,F20.2,A)') "Processed k = ", ik, " / ", NKPTS, "    Remaining time: ", remain_time, " sec"
      end if

      if(isym_para == .true.) then
         ikk=NCHTS(ik); isymm=NSYMM(ik)
      else
         ikk = ik
      endif
      ! eigmat !
      eval(1:lda)  = eig     (:      ,ikk)
      write(3001,"(I5,80000E14.6)") ik, eval(1:lda)
      ! vmat !
      vmat(:,:,:)  = vmat_IBZ(:,:,1:3,ikk) 
      if(isym_para == .true.) then
         call ikk2fuk(lda,3,ISYMM,vmat(:,:,1:3))
      endif
      write(3003,'(A,I5)') 'k=',ik
      write(3003,"(8E14.6)") vmat(:,:,1) !
      write(3003,"(8E14.6)") vmat(:,:,2) !
      ! smat !
      if ((tagspn == 1)) then
         smat(:,:,:)= smat_IBZ(:,:,1:3,ikk)
         if(isym_para == .true.) then
            call ikk2fuk(lda,2,ISYMM,smat(:,:,1:3))
         endif
         write(3002,'(A,I5)') 'k=',ik
         write(3002,"(8E14.6)") smat(:,:,1) !    ! sigma mat in FBZ
         write(3002,"(8E14.6)") smat(:,:,2) !
         write(3002,"(8E14.6)") smat(:,:,3) !
         smat = 0.50_dp * smat  ! spin angular momentum in [\hbar]      s = \hbar/2 sigma
      endif


      Jmat(:,:,:,:)=czero;Atmp=czero;Atmp2=czero
      Jmat(:,:,:,0)=vmat(:,:,:)
      do j=1,3
         do iv=1,3
            Atmp =matmul(vmat(:,:,iv),smat(:,:,j))
            Atmp2=matmul(smat(:,:,j),vmat(:,:,iv))
            Jmat(:,:,iv,j)=cmplx(0.5_dp,0._dp,dp)*(Atmp+Atmp2)
         enddo
      enddo

       DHDk=czero
       DHDkdag=czero
       Js=czero
       DHDk_E =czero
!-----------------tagn==1
       if(tagn==1) then  ! noe
       do n= 1, lda
       do m= n+1, lda
          if (n <= nocc    .and. m  > nocc ) then !n=occ m=unocc
             emn=eval(m)-eval(n)
             if(abs(emn)<0.0001_dp) emn=0.0001_dp   
             do iv=1,3
             DHDk   (n, m,iv)= vmat(n, m,iv)/cmplx(0._dp,emn,dp)
             DHDkdag(m, n,iv)= vmat(m, n,iv)/cmplx(0._dp,emn,dp)
                do j=0,3
                   Js(n, m,iv,j)= Jmat(n, m,iv,j)/cmplx(0._dp,emn,dp)
                enddo
             enddo
            !---------------------------dielectric constant-------------------------------------!
            do dir =1,6 !xx xy xz yy yz zz
               dielectric_kmesh(dir,ik) = dielectric_kmesh(dir,ik) + coeff_eps * 1.0_dp /(emn**3) * REAL( vmat(m, n,dir1(dir))*vmat(n, m,dir2(dir)) )
            enddo
            !---------------------------dielectric constant-------------------------------------!
          else
          endif
       enddo ! n
       enddo ! m
      endif !!!

!-----------------tagm==1
       if(tagm==1) then  ! Ef
       do n= 1, lda
       do m= n+1, lda
          if (eval(n)< mu .and. eval(m)> mu) then !n=occ m=unocc
             emn=eval(m)-eval(n)
             if(abs(emn)<0.0001_dp) emn = 0.0001_dp
             do iv=1,3
             DHDk   (n, m,iv)= vmat(n, m,iv)/cmplx(0._dp,emn,dp)
             DHDkdag(m, n,iv)= vmat(m, n,iv)/cmplx(0._dp,emn,dp)
                do j=0,3
                   Js(n, m,iv,j)= Jmat(n, m,iv,j)/cmplx(0._dp,emn,dp)
                enddo
             enddo
            !---------------------------dielectric constant-------------------------------------!
            do dir =1,6 !xx xy xz yy yz zz
               dielectric_kmesh(dir,ik) = dielectric_kmesh(dir,ik) + coeff_eps * 1.0_dp/(emn**3) * REAL( vmat(m, n,dir1(dir))*vmat(n, m,dir2(dir)) )
            enddo
            !---------------------------dielectric constant-------------------------------------!
          else
          endif
       enddo ! n
       enddo ! m
      endif !!!

      if (tagnb == 1) then
            !---------------------------berry_curvature_select,spn_or_orb_berry_select,orbital_magnetism_kmesh (select band)-------------------------------------!
         do nnbb = 1,num_select
         do m = 1,lda
               if( m == nnbb ) cycle
               emn=eval(nnbb)-eval(m)
               if(abs(emn)<0.0001_dp) emn=sign(0.0001_dp, emn) 
            do dir = 1,3 !xy-z yz-x zx-y
               berry_curvature_select(dir,nnbb,ik) = berry_curvature_select(dir,nnbb,ik) + coeff_berry * AIMAG(vmat(nnbb, m,dir2(dir))*vmat(m, nnbb,dir3(dir))) / (emn**2) 
               spn_or_orb_berry_select(1:3,dir,nnbb,ik) = spn_or_orb_berry_select(1:3,dir,nnbb,ik) + 1.0_dp * coeff_berry * AIMAG(Jmat(nnbb, m,dir2(dir),1:3)*vmat(m, nnbb,dir3(dir))) / (emn**2)    !here J is calculated by the 1/2{vx,sigma_z} ; but real J = 1/2{vx,s_Z}, so we obsorb hbar in coeff_berry 
            enddo
         enddo ! m
         enddo ! nnbb
            !------------------------------end---berry_curvature_select,spn_or_orb_berry_select,orbital_magnetism_kmesh (select band)-------------------------------------!
      endif


!-----------------
       Atmp = 0.00_dp
       berry_tensor_tmp(:,:)=0._dp
       do i=1,3
          j=i+1
          if(j==4) j=1
          Atmp=matmul(Js(:,:,i,0),DHDkdag(:,:,j))
          Omega=czero
          do iv=1,lda         
              Omega=Omega+Atmp(iv,iv)
          enddo
          berry_tensor_tmp(i,1)=berry_tensor_tmp(i,1) - coeff_berry *AIMAG(Omega)

          if (tagspn == 1) then
            Atmp=matmul(Js(:,:,i,1),DHDkdag(:,:,j))
            Omega=czero
            do iv=1,lda         
               Omega=Omega+Atmp(iv,iv)
            enddo
            berry_tensor_tmp(i,2)=berry_tensor_tmp(i,2) - 1.0_dp * coeff_berry *AIMAG(Omega)

            Atmp=matmul(Js(:,:,i,2),DHDkdag(:,:,j))
            Omega=czero
            do iv=1,lda         
               Omega=Omega+Atmp(iv,iv)
            enddo
            berry_tensor_tmp(i,3)=berry_tensor_tmp(i,3) - 1.0_dp * coeff_berry *AIMAG(Omega)

            Atmp=matmul(Js(:,:,i,3),DHDkdag(:,:,j))
            Omega=czero
            do iv=1,lda         
               Omega=Omega+Atmp(iv,iv)
            enddo
            berry_tensor_tmp(i,4)=berry_tensor_tmp(i,4) - 1.0_dp * coeff_berry *AIMAG(Omega)
          endif
       enddo
      berry_tensor_kmesh(:,:,ik) = berry_tensor_tmp  !(3,4)



      !-------------------dielectric and berry---------------------!
      dielectric_constant = dielectric_constant + dielectric_kmesh(1:6,ik)
      AHE_conductance = AHE_conductance - 1.0d0 /(volume*NKPTS) * berry_tensor_tmp(:,1)

      !-------------------spin hall--------------------------------!
      if (tagspn == 1) then
         SHE_conductance = SHE_conductance + 1.0d0 /(volume*NKPTS) * berry_tensor_tmp(:,2:4)
      endif

      if (tagtest == 1) then
      write(3009,'(3F10.6,2X,1E12.4,3X,3E12.4)') fullK_dirct(1:3,ik),eval(select_bands(num_select))-eval(select_bands(1)),&
                                                abs(vmat(select_bands(1),select_bands(num_select),1)),&
                                                abs(vmat(select_bands(1),select_bands(num_select),2)),&
                                                abs(vmat(select_bands(1),select_bands(num_select),3)) !test
      endif


   enddo

   !-------------------output---------------------!
   dielectric_constant(1) = dielectric_constant(1) + 1
   dielectric_constant(4) = dielectric_constant(4) + 1
   dielectric_constant(6) = dielectric_constant(6) + 1


   !-------------------dielectric and berry---------------------!
   open(unit=2001, file=out_dielectric, status='replace')
   open(unit=2002, file=out_berry_AHE , status='replace')
   if (isym_para == .true.) write(2001,'(A32,6E12.4)') '# dielectric constant (SUM) :',dielectric_constant
   if (isym_para == .true.) write(2001, '(A1,A9,2A10,2X,6A12,1A50)') '#', 'ka', 'kb', 'kc', 'xx', 'xy', 'xz', 'yy', 'yz', 'zz','epsilon_0 (permittivity of free space)'
   if (isym_para ==.false.) write(2001, '(A1,A9,2A10,2X,6A12,1A50)') '#', 'ka', 'kb', 'kc', 'xx', 'xy', 'xz', 'yy', 'yz', 'zz','epsilon_0 * ang^3'
   if (isym_para == .true.) write(2002,'(A32,3E12.4)') '# AHE (in e^2/h/ang) :',AHE_conductance * 2.0d0 * pi    ! convert e^2/hbar to e^2/h
   if (isym_para == .true.) write(2002,'(A32,3E12.4)') '# AHE (in S/cm)      :', AHE_conductance * 2.4341348E-4 * 1.0E8   ! e^2/hbar = 2.4341348E-4 Ohm
   write(2002, '(A1,A9,2A10,2X,3A12,1A10)') '#', 'ka', 'kb', 'kc', 'xy', 'yz', 'zx','ang^2'


   !-------------------spin hall--------------------------------!
   if ((tagspn == 1)) then
      open(unit=2104, file=out_spin_berry_SHE_x , status='replace')
      open(unit=2105, file=out_spin_berry_SHE_y , status='replace')
      open(unit=2106, file=out_spin_berry_SHE_z , status='replace')
      if (isym_para == .true.) write(2104,'(A32,3E12.4)') '# SHE (in e/(2pi)/ang)   :', SHE_conductance(:,1)* 2.0d0 * pi 
      if (isym_para == .true.) write(2104,'(A32,3E12.4)') '# SHE (in (hbar/e)*S/cm) :', SHE_conductance(:,1) * 2.4341348E4 
      write(2104, '(A1,A9,2A10,2X,3A12,1A10)') '#', 'ka', 'kb', 'kc', 'x_xy', 'x_yz', 'x_zx','ang^2'

      if (isym_para == .true.) write(2105,'(A32,3E12.4)') '# SHE (in e/(2pi)/ang)   :', SHE_conductance(:,2)* 2.0d0 * pi   
      if (isym_para == .true.) write(2105,'(A32,3E12.4)') '# SHE (in (hbar/e)*S/cm) :', SHE_conductance(:,2) * 2.4341348E4
      write(2105, '(A1,A9,2A10,2X,3A12,1A10)') '#', 'ka', 'kb', 'kc', 'y_xy', 'y_yz', 'y_zx','ang^2'

      if (isym_para == .true.) write(2106,'(A32,3E12.4)') '# SHE (in e/(2pi)/ang)   :', SHE_conductance(:,3)* 2.0d0 * pi  
      if (isym_para == .true.) write(2106,'(A32,3E12.4)') '# SHE (in (hbar/e)*S/cm) :', SHE_conductance(:,3) * 2.4341348E4
      write(2106, '(A1,A9,2A10,2X,3A12,1A10)') '#', 'ka', 'kb', 'kc', 'z_xy', 'z_yz', 'z_zx','ang^2'

   endif

   do ik=1,NKPTS
      write(2001,'(3F10.6,2X,6E12.4)') fullK_dirct(1:3,ik),dielectric_kmesh(1:6,ik)
      write(2002,'(3F10.6,2X,3E12.4)') fullK_dirct(1:3,ik),berry_tensor_kmesh(:,1,ik)
      if ((tagspn == 1)) then
         write(2104,'(3F10.6,2X,3E12.4)') fullK_dirct(1:3,ik),berry_tensor_kmesh(:,2,ik)
         write(2105,'(3F10.6,2X,3E12.4)') fullK_dirct(1:3,ik),berry_tensor_kmesh(:,3,ik)
         write(2106,'(3F10.6,2X,3E12.4)') fullK_dirct(1:3,ik),berry_tensor_kmesh(:,4,ik)
      endif
      if (mod(ik,NKPX*NKPY) == 0) then
         write(2001,'(X)');write(2001,'(X)')
         write(2002,'(X)');write(2002,'(X)')
         if ((tagspn == 1)) then
            write(2104,'(X)');write(2104,'(X)')
            write(2105,'(X)');write(2105,'(X)')
            write(2106,'(X)');write(2106,'(X)')
         endif
      endif
   enddo


   !-------------------select band--------------------------------!
   if (tagnb == 1) then 
      write(*,*)  " writing select bands files"
      open(unit=2003, file=out_berry_select, status='replace')
      write(2003,'(a)') '# k-resolved berry curvature (selected bands)'
      if ( (tagspn == 0)) then
         do nnbb = 1,num_select
            write(2003,'(1A6,1I4,1A4,2A10,2X,3A12,1A10)') '# band', select_bands(nnbb), 'ka','kb','kc','xy','yz','zx','ang^2'
            do ik = 1,NKPTS
               write(2003,'(1F14.6,2F10.6,2X,3E12.4)') fullK_dirct(1,ik),fullK_dirct(2,ik),fullK_dirct(3,ik),berry_curvature_select(1:3,nnbb,ik)
            enddo
            write(2003,*)
            write(2003,*)
         enddo
         close(2003) ! select berry
      endif
      if (tagspn == 1) then
      open(unit=2005, file=out_spin_berry_select , status='replace')
      write(2005,'(a)') '# k-resolved spin-berry curvature (selected bands)'
         do nnbb = 1,num_select
            write(2003,'(1A6,1I4,1A4,2A10,2X,3A12,1A10)') '# band', select_bands(nnbb), 'ka','kb','kc','xy','yz','zx','ang^2'
            write(2005,'(1A6,1I4,1A4,2A10,2X,3A12,X,3A12,X,3A12,1A10)') '# band', select_bands(nnbb), 'ka','kb','kc', 'x_xy', 'x_yz', 'x_zx', 'y_xy', 'y_yz', 'y_zx', 'z_xy', 'z_yz', 'z_zx','ang^2'
            do ik = 1,NKPTS
               write(2003,'(1F14.6,2F10.6,2X,3E12.4)') fullK_dirct(1,ik),fullK_dirct(2,ik),fullK_dirct(3,ik),berry_curvature_select(1:3,nnbb,ik)
               write(2005,'(1F14.6,2F10.6,2X,3E12.4,X,3E12.4,X,3E12.4)') fullK_dirct(1,ik),fullK_dirct(2,ik),fullK_dirct(3,ik),spn_or_orb_berry_select(1,1,nnbb,ik),spn_or_orb_berry_select(1,2,nnbb,ik),spn_or_orb_berry_select(1,3,nnbb,ik),&
                                                         spn_or_orb_berry_select(2,1,nnbb,ik),spn_or_orb_berry_select(2,2,nnbb,ik),spn_or_orb_berry_select(2,3,nnbb,ik),&
                                                         spn_or_orb_berry_select(3,1,nnbb,ik),spn_or_orb_berry_select(3,2,nnbb,ik),spn_or_orb_berry_select(3,3,nnbb,ik)
            enddo
            write(2003,*)
            write(2003,*)
            write(2005,*)
            write(2005,*)
         enddo
            close(2003) ! select berry
            close(2005) ! select spin berry
      endif
   endif

   close(2001) ! dielectric
   close(2002) ! berry and AHE

   close(3001) ! eig mat
   close(3003) ! vmat
   if (tagspn == 1) then
   close(2104);   close(2105);   close(2106) ! spin berry and SHE
   close(3002) ! smat
   endif
   if (tagtest == 1) then
   close(3009) ! test
   endif
   deallocate(eig,vmat,smat,Jmat,DHDk,DHDkdag,Js,dielectric_kmesh,berry_curvature_select,spn_or_orb_berry_select,orbital_magnetism_kmesh)
   if (isym_para == .true.)  then
      deallocate(NCHTS,NSYMM)
   endif
   deallocate(vmat_IBZ)
   if (tagspn == 1) then
   deallocate(smat_IBZ)
   endif
   if (tagorb == 1) then
   deallocate(smat_IBZ,omat_IBZ)
   endif
   write(*,'(a)') 'Job finished!!'
   write(*,'(a)') "Please cite: VASP2KP: k⋅p Models and Landé g-Factors from ab initio Calculations, Chin. Phys. Lett. 40, 127101 (2023). Thank you!"
end program berry_curvature


